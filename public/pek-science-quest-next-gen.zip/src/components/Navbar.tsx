import React, { useState } from 'react';
import {
  ShieldAlert,
  Volume2,
  VolumeX,
  Music,
  Maximize,
  Minimize,
  Radio,
  Sparkles,
  LogOut,
  Users,
  Compass,
  Map as MapIcon,
  Package,
} from 'lucide-react';
import { Team, ActiveTab } from '../types';
import { audioManager } from '../services/audioManager';
import { storageService } from '../services/storageService';
import { ConfirmModal } from './ConfirmModal';
import { AdminLoginModal } from './AdminLoginModal';

interface NavbarProps {
  currentTeam: Team | null;
  activeTab: ActiveTab;
  setActiveTab: (tab: ActiveTab) => void;
  onExitTeam?: () => void;
  onViewMap?: () => void;
  onOpenInventory?: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  currentTeam,
  activeTab,
  setActiveTab,
  onExitTeam,
  onViewMap,
  onOpenInventory,
}) => {
  const [soundOn, setSoundOn] = useState<boolean>(audioManager.isEnabled());
  const [bgmOn, setBgmOn] = useState<boolean>(audioManager.isBgmPlaying());
  const [isFullscreen, setIsFullscreen] = useState<boolean>(false);
  const [showExitConfirm, setShowExitConfirm] = useState<boolean>(false);
  const [showAdminLoginModal, setShowAdminLoginModal] = useState<boolean>(false);

  const handleSwitchToAdmin = () => {
    if (storageService.isAdminAuthenticated()) {
      setActiveTab('admin');
    } else {
      setShowAdminLoginModal(true);
    }
  };

  const handleAdminLogout = () => {
    storageService.logoutAdmin();
    setActiveTab('player');
    audioManager.playPop();
  };

  const toggleSound = () => {
    const next = audioManager.toggleSound();
    setSoundOn(next);
    setBgmOn(audioManager.isBgmPlaying());
  };

  const toggleBgm = () => {
    const next = audioManager.toggleBgm();
    setBgmOn(next);
  };

  const toggleFullscreen = () => {
    if (!document.fullscreenElement) {
      document.documentElement.requestFullscreen().catch(() => {});
      setIsFullscreen(true);
    } else {
      if (document.exitFullscreen) {
        document.exitFullscreen().catch(() => {});
        setIsFullscreen(false);
      }
    }
  };

  const handleLogout = () => {
    setShowExitConfirm(true);
  };

  const confirmExitAction = () => {
    storageService.setCurrentTeamId(null);
    if (onExitTeam) onExitTeam();
    setShowExitConfirm(false);
  };

  return (
    <header className="sticky top-0 z-40 w-full border-b border-amber-200/80 bg-white/95 backdrop-blur-xl shadow-sm">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 h-16 sm:h-20 flex items-center justify-between gap-2">
        {/* Brand */}
        <div
          onClick={() => {
            setActiveTab('player');
            if (onViewMap) onViewMap();
          }}
          className="flex items-center gap-3 cursor-pointer group select-none"
        >
          <div className="relative w-10 h-10 sm:w-11 sm:h-11 rounded-xl bg-gradient-to-tr from-amber-400 via-sky-400 to-indigo-500 p-0.5 shadow-md shadow-amber-400/20 group-hover:shadow-amber-400/40 transition-all">
            <div className="w-full h-full bg-white rounded-[10px] flex items-center justify-center">
              <Compass className="w-6 h-6 text-amber-600 group-hover:rotate-45 transition-transform duration-300" />
            </div>
            <div className="absolute -top-1 -right-1 w-3 h-3 bg-amber-400 rounded-full animate-ping opacity-75" />
          </div>

          <div>
            <div className="flex items-center gap-1.5">
              <span className="font-extrabold tracking-tight text-base sm:text-lg bg-gradient-to-r from-amber-600 via-sky-600 to-indigo-600 bg-clip-text text-transparent">
                PEK SCIENCE QUEST
              </span>
              <span className="hidden sm:inline-block px-1.5 py-0.5 text-[10px] font-bold rounded bg-amber-100 text-amber-800 border border-amber-300 font-mono">
                NEXT GEN
              </span>
            </div>
            <p className="text-[11px] text-slate-500 tracking-wide line-clamp-1 font-medium">
              Tổ KHTN – Trường PeK
            </p>
          </div>
        </div>

        {/* Center: Active Team Mission Badge with Captain + Quick Map/Inventory links */}
        {currentTeam && activeTab === 'player' && (
          <div className="hidden lg:flex items-center gap-3 bg-slate-50 border border-amber-200/80 rounded-full px-4 py-1.5 shadow-sm">
            <div className="flex items-center gap-2">
              <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse" />
              <span className="font-bold text-sm text-slate-800">
                {currentTeam.teamName}
              </span>
              <span className="text-xs text-sky-700 bg-sky-100 px-2 py-0.5 rounded font-mono font-bold">
                {currentTeam.className}
              </span>
              {currentTeam.captainName && (
                <span className="text-[11px] text-slate-500 font-medium">
                  • Đội trưởng: <strong className="text-slate-700">{currentTeam.captainName}</strong>
                </span>
              )}
            </div>

            <div className="h-4 w-px bg-slate-300" />

            <div className="flex items-center gap-2 font-mono text-xs">
              <span className="text-slate-500 font-semibold">Vòng {currentTeam.currentRound}/4</span>
              <span className="text-amber-800 font-black bg-amber-100 px-2 py-0.5 rounded border border-amber-300">
                {currentTeam.score} pts
              </span>
            </div>

            {/* Quick Map and Inventory shortcuts */}
            {onViewMap && (
              <button
                onClick={onViewMap}
                className="px-2.5 py-1 rounded-full bg-amber-100 hover:bg-amber-200 text-amber-900 text-xs font-bold flex items-center gap-1 transition-all cursor-pointer"
                title="Xem Bản Đồ Kho Báu"
              >
                <MapIcon className="w-3.5 h-3.5" />
                <span>Bản Đồ</span>
              </button>
            )}

            {onOpenInventory && (
              <button
                onClick={onOpenInventory}
                className="px-2.5 py-1 rounded-full bg-sky-100 hover:bg-sky-200 text-sky-900 text-xs font-bold flex items-center gap-1 transition-all cursor-pointer"
                title="Mở Kho Đồ Thám Hiểm"
              >
                <Package className="w-3.5 h-3.5" />
                <span>Kho Đồ ({Math.min(4, Math.max(0, currentTeam.currentRound - 1))}/4)</span>
              </button>
            )}
          </div>
        )}

        {/* Right Action Controls */}
        <div className="flex items-center gap-1.5 sm:gap-2">
          {/* Sound FX Toggle */}
          <button
            onClick={toggleSound}
            title={soundOn ? 'Tắt âm thanh hiệu ứng' : 'Bật âm thanh hiệu ứng'}
            className={`p-2 rounded-xl border transition-all cursor-pointer ${
              soundOn
                ? 'bg-amber-50 border-amber-300 text-amber-700 hover:bg-amber-100 shadow-sm'
                : 'bg-slate-100 border-slate-200 text-slate-400 hover:text-slate-600'
            }`}
          >
            {soundOn ? <Volume2 className="w-4 h-4 sm:w-5 sm:h-5" /> : <VolumeX className="w-4 h-4 sm:w-5 sm:h-5" />}
          </button>

          {/* Ambient BGM Synth Toggle */}
          <button
            onClick={toggleBgm}
            title={bgmOn ? 'Tắt nhạc nền' : 'Bật nhạc nền'}
            className={`p-2 rounded-xl border transition-all cursor-pointer ${
              bgmOn
                ? 'bg-indigo-50 border-indigo-300 text-indigo-600 shadow-sm animate-pulse'
                : 'bg-slate-100 border-slate-200 text-slate-400 hover:text-slate-600'
            }`}
          >
            <Music className="w-4 h-4 sm:w-5 sm:h-5" />
          </button>

          {/* Fullscreen Button */}
          <button
            onClick={toggleFullscreen}
            title="Toàn màn hình"
            className="hidden sm:flex p-2 rounded-xl bg-slate-100 border border-slate-200 text-slate-600 hover:text-sky-600 transition-all cursor-pointer"
          >
            {isFullscreen ? <Minimize className="w-4 h-4" /> : <Maximize className="w-4 h-4" />}
          </button>

          {/* Switch Tab: Player <-> Game Master */}
          <div className="flex items-center bg-slate-100 border border-slate-200 rounded-xl p-0.5">
            <button
              onClick={() => setActiveTab('player')}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer ${
                activeTab === 'player'
                  ? 'bg-sky-600 text-white shadow-sm font-black'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <Users className="w-3.5 h-3.5" />
              <span>Đội Chơi</span>
            </button>
            <button
              onClick={handleSwitchToAdmin}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer ${
                activeTab === 'admin'
                  ? 'bg-gradient-to-r from-indigo-600 to-purple-600 text-white shadow-sm font-black'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <ShieldAlert className="w-3.5 h-3.5" />
              <span>Game Master</span>
            </button>
          </div>

          {/* Admin Lock / Logout button when in Game Master view */}
          {activeTab === 'admin' && (
            <button
              onClick={handleAdminLogout}
              title="Khóa Game Master (Đăng xuất quản trị)"
              className="p-2 rounded-xl bg-indigo-50 border border-indigo-200 text-indigo-700 hover:bg-indigo-100 transition-all cursor-pointer flex items-center gap-1 text-xs font-bold"
            >
              <LogOut className="w-4 h-4" />
              <span className="hidden md:inline">Khóa Quản Trị</span>
            </button>
          )}

          {/* Logout active team if player is active */}
          {currentTeam && activeTab === 'player' && (
            <button
              onClick={handleLogout}
              title="Đổi đội chơi / Thoát phiên"
              className="p-2 rounded-xl bg-red-50 border border-red-200 text-red-600 hover:bg-red-100 transition-all cursor-pointer"
            >
              <LogOut className="w-4 h-4" />
            </button>
          )}
        </div>
      </div>

      {/* Admin Password Login Modal */}
      <AdminLoginModal
        isOpen={showAdminLoginModal}
        onSuccess={() => {
          setShowAdminLoginModal(false);
          setActiveTab('admin');
        }}
        onClose={() => setShowAdminLoginModal(false)}
      />

      {/* Exit Team Confirmation Modal */}
      <ConfirmModal
        isOpen={showExitConfirm}
        title="Rời Phiên Chơi Hiện Tại"
        message="Bạn có chắc chắn muốn rời phiên của đội hiện tại? Toàn bộ điểm số và kết quả đã lưu sẽ không bị mất, bạn có thể quay lại bất cứ lúc nào bằng mã đội."
        confirmText="Xác Nhận Rời"
        cancelText="Ở Lại Chơi Tiếp"
        type="warning"
        onConfirm={confirmExitAction}
        onCancel={() => setShowExitConfirm(false)}
      />
    </header>
  );
};
