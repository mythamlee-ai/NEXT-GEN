import React from 'react';
import {
  Compass,
  Map as MapIcon,
  Search,
  Sparkles,
  AlertTriangle,
  Lightbulb,
  PartyPopper,
  Zap,
} from 'lucide-react';

export type ChibiExpression =
  | 'idle'
  | 'waving'
  | 'pointing'
  | 'thinking'
  | 'surprised'
  | 'celebrating'
  | 'excited'
  | 'warning'
  | 'greeting'
  | 'scanning'
  | 'treasure';

interface ChibiMascotProps {
  expression?: ChibiExpression;
  size?: 'sm' | 'md' | 'lg' | 'xl';
  variant?: 'chibi_scientist' | 'chibi_robot' | 'svg_scientist';
  className?: string;
  showSpeechBubble?: boolean;
  speechText?: string;
  accessory?: 'magnifier' | 'map' | 'compass' | 'backpack' | 'flask';
}

export const ChibiMascot: React.FC<ChibiMascotProps> = ({
  expression = 'idle',
  size = 'md',
  variant = 'chibi_scientist',
  className = '',
  showSpeechBubble = false,
  speechText,
  accessory,
}) => {
  const sizeMap = {
    sm: 'w-16 h-16',
    md: 'w-24 h-24',
    lg: 'w-32 h-32',
    xl: 'w-44 h-44',
  };

  const imageMap = {
    chibi_scientist: '/src/assets/images/chibi_mascot_1791188388736.jpg',
    chibi_robot: '/src/assets/images/chibi_robot_1791188420275.jpg',
    svg_scientist: '',
  };

  // Expression Badge Icon & Animation
  const getExpressionBadge = () => {
    switch (expression) {
      case 'celebrating':
      case 'excited':
        return { icon: <PartyPopper className="w-3.5 h-3.5 text-amber-500" />, label: 'Yay!', border: 'border-amber-400', anim: 'animate-bounce' };
      case 'warning':
        return { icon: <AlertTriangle className="w-3.5 h-3.5 text-rose-500" />, label: 'Cẩn thận!', border: 'border-rose-400', anim: 'animate-pulse' };
      case 'thinking':
        return { icon: <Lightbulb className="w-3.5 h-3.5 text-yellow-500" />, label: 'Suy ngẫm...', border: 'border-yellow-400', anim: 'animate-spin' };
      case 'surprised':
        return { icon: <Zap className="w-3.5 h-3.5 text-cyan-500" />, label: 'Woa!', border: 'border-cyan-400', anim: 'animate-ping' };
      case 'pointing':
        return { icon: <Compass className="w-3.5 h-3.5 text-indigo-500" />, label: 'Hướng kia!', border: 'border-indigo-400', anim: 'animate-pulse' };
      case 'waving':
      case 'greeting':
        return { icon: <Sparkles className="w-3.5 h-3.5 text-sky-500" />, label: 'Chào bạn!', border: 'border-sky-400', anim: 'animate-pulse' };
      case 'scanning':
        return { icon: <Search className="w-3.5 h-3.5 text-sky-500" />, label: 'Đang dò...', border: 'border-sky-400', anim: 'animate-spin' };
      case 'treasure':
        return { icon: <span className="text-xs">💎</span>, label: 'Kho báu!', border: 'border-amber-400', anim: 'animate-bounce' };
      case 'idle':
      default:
        return { icon: <Sparkles className="w-3.5 h-3.5 text-sky-500" />, label: 'Sẵn sàng', border: 'border-sky-400', anim: '' };
    }
  };

  const badge = getExpressionBadge();

  return (
    <div className={`relative inline-flex flex-col items-center select-none ${className}`}>
      {/* Speech Bubble */}
      {showSpeechBubble && speechText && (
        <div className="mb-2 relative bg-white border-2 border-sky-400 text-slate-800 text-xs font-bold px-3.5 py-2 rounded-2xl shadow-lg max-w-xs text-center animate-bounce-gentle z-20">
          <div className="flex items-center justify-center gap-1.5 mb-0.5 text-[10px] font-mono uppercase text-sky-600">
            <Compass className="w-3 h-3 text-sky-500" />
            <span>PeK Treasure Guide</span>
          </div>
          <p className="leading-relaxed">{speechText}</p>
          <div className="absolute -bottom-1.5 left-1/2 -translate-x-1/2 w-3 h-3 bg-white border-r-2 border-b-2 border-sky-400 rotate-45" />
        </div>
      )}

      {/* Main Avatar Container */}
      <div className={`${sizeMap[size]} relative filter drop-shadow-xl transition-transform hover:scale-105 duration-200`}>
        {/* Glow Ring & Theme Rim */}
        <div className="w-full h-full rounded-full p-1 bg-gradient-to-tr from-sky-400 via-amber-300 to-indigo-500 shadow-md">
          <img
            src={imageMap[variant === 'chibi_robot' ? 'chibi_robot' : 'chibi_scientist']}
            alt="PeK Treasure Guide Mascot"
            referrerPolicy="no-referrer"
            className="w-full h-full object-cover rounded-full border-2 border-white shadow-inner bg-white"
          />
        </div>

        {/* Expression Badge */}
        <span
          className={`absolute -bottom-1 -right-1 w-7 h-7 rounded-full bg-white border-2 ${badge.border} flex items-center justify-center text-xs shadow-md z-10 ${badge.anim}`}
          title={badge.label}
        >
          {badge.icon}
        </span>

        {/* Optional Accessory Pin */}
        {accessory && (
          <span className="absolute -top-1 -left-1 w-6 h-6 rounded-full bg-amber-100 border border-amber-300 flex items-center justify-center text-xs shadow-sm z-10">
            {accessory === 'magnifier' && '🔍'}
            {accessory === 'map' && '🗺️'}
            {accessory === 'compass' && '🧭'}
            {accessory === 'backpack' && '🎒'}
            {accessory === 'flask' && '🧪'}
          </span>
        )}
      </div>
    </div>
  );
};
