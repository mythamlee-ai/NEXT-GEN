import { Teacher } from '../types';
import { GV01_AVATAR_SVG, GV02_AVATAR_SVG, GV03_AVATAR_SVG } from './officialTeachers';

/**
 * High-definition SVG Avatars for GV04 -> GV10
 */

export const GV04_AVATAR_SVG = `data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 400 400" width="100%" height="100%">
  <defs>
    <linearGradient id="bgGrad4" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="%23064e3b" />
      <stop offset="100%" stop-color="%23047857" />
    </linearGradient>
    <linearGradient id="skinGrad4" x1="0%" y1="0%" x2="0%" y2="100%">
      <stop offset="0%" stop-color="%23fed7aa" />
      <stop offset="100%" stop-color="%23fcd34d" />
    </linearGradient>
  </defs>
  <rect width="400" height="400" rx="36" fill="url(%23bgGrad4)" />
  <circle cx="200" cy="180" r="140" fill="%2334d399" opacity="0.15" />
  <!-- Body -->
  <path d="M110,380 L110,330 Q120,280 200,280 Q280,280 290,330 L290,380 Z" fill="%23065f46" stroke="%236ee7b7" stroke-width="3" />
  <polygon points="175,280 200,330 225,280" fill="%23ffffff" />
  <!-- Neck & Head -->
  <rect x="180" y="240" width="40" height="50" rx="8" fill="url(%23skinGrad4)" />
  <ellipse cx="200" cy="180" rx="65" ry="75" fill="url(%23skinGrad4)" />
  <!-- Hair & Glasses -->
  <path d="M130,170 Q130,110 200,105 Q270,110 270,170 Q240,120 200,125 Q150,125 130,170 Z" fill="%231e293b" />
  <circle cx="170" cy="180" r="20" fill="%23ecfdf5" fill-opacity="0.3" stroke="%23064e3b" stroke-width="3" />
  <circle cx="230" cy="180" r="20" fill="%23ecfdf5" fill-opacity="0.3" stroke="%23064e3b" stroke-width="3" />
  <line x1="190" y1="180" x2="210" y2="180" stroke="%23064e3b" stroke-width="3" />
  <circle cx="170" cy="180" r="4" fill="%23064e3b" />
  <circle cx="230" cy="180" r="4" fill="%23064e3b" />
  <path d="M185,220 Q200,235 215,220" stroke="%23047857" stroke-width="3" fill="none" stroke-linecap="round" />
  <rect x="100" y="350" width="200" height="36" rx="18" fill="%23047857" stroke="%2334d399" stroke-width="2" />
  <text x="200" y="373" font-family="sans-serif" font-weight="900" font-size="13" fill="%23ffffff" text-anchor="middle">THẦY KHOA • SINH HỌC</text>
</svg>`;

export const GV05_AVATAR_SVG = `data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 400 400" width="100%" height="100%">
  <defs>
    <linearGradient id="bgGrad5" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="%231e1b4b" />
      <stop offset="100%" stop-color="%234338ca" />
    </linearGradient>
    <linearGradient id="skinGrad5" x1="0%" y1="0%" x2="0%" y2="100%">
      <stop offset="0%" stop-color="%23fed7aa" />
      <stop offset="100%" stop-color="%23fdba74" />
    </linearGradient>
  </defs>
  <rect width="400" height="400" rx="36" fill="url(%23bgGrad5)" />
  <circle cx="200" cy="180" r="140" fill="%23818cf8" opacity="0.15" />
  <path d="M110,380 L110,330 Q120,280 200,280 Q280,280 290,330 L290,380 Z" fill="%23312e81" stroke="%23a5b4fc" stroke-width="3" />
  <polygon points="175,280 200,325 225,280" fill="%23ffffff" />
  <rect x="182" y="240" width="36" height="50" rx="8" fill="url(%23skinGrad5)" />
  <ellipse cx="200" cy="180" rx="62" ry="72" fill="url(%23skinGrad5)" />
  <!-- Hair waves -->
  <path d="M125,170 Q130,110 200,105 Q270,110 275,170 Q240,115 200,120 Q160,115 125,170 Z" fill="%23311005" />
  <path d="M115,180 Q105,260 120,330 L140,200 Z" fill="%23311005" />
  <path d="M285,180 Q295,260 280,330 L260,200 Z" fill="%23311005" />
  <circle cx="170" cy="175" r="5" fill="%231e1b4b" />
  <circle cx="230" cy="175" r="5" fill="%231e1b4b" />
  <path d="M182,215 Q200,235 218,215" stroke="%23e11d48" stroke-width="3.5" fill="%23ffe4e6" stroke-linecap="round" />
  <rect x="100" y="350" width="200" height="36" rx="18" fill="%234338ca" stroke="%23818cf8" stroke-width="2" />
  <text x="200" y="373" font-family="sans-serif" font-weight="900" font-size="13" fill="%23ffffff" text-anchor="middle">CÔ THẢO • HÓA HỌC</text>
</svg>`;

export const GV06_AVATAR_SVG = `data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 400 400" width="100%" height="100%">
  <defs>
    <linearGradient id="bgGrad6" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="%237c2d12" />
      <stop offset="100%" stop-color="%23c2410c" />
    </linearGradient>
    <linearGradient id="skinGrad6" x1="0%" y1="0%" x2="0%" y2="100%">
      <stop offset="0%" stop-color="%23fed7aa" />
      <stop offset="100%" stop-color="%23fcd34d" />
    </linearGradient>
  </defs>
  <rect width="400" height="400" rx="36" fill="url(%23bgGrad6)" />
  <circle cx="200" cy="180" r="140" fill="%23fb923c" opacity="0.15" />
  <path d="M110,380 L110,330 Q120,280 200,280 Q280,280 290,330 L290,380 Z" fill="%239a3412" stroke="%23fdba74" stroke-width="3" />
  <polygon points="175,280 200,325 225,280" fill="%23ffffff" />
  <rect x="180" y="240" width="40" height="50" rx="8" fill="url(%23skinGrad6)" />
  <ellipse cx="200" cy="180" rx="65" ry="75" fill="url(%23skinGrad6)" />
  <path d="M130,165 Q135,105 200,105 Q265,105 270,165 Z" fill="%2318181b" />
  <circle cx="170" cy="178" r="5" fill="%2318181b" />
  <circle cx="230" cy="178" r="5" fill="%2318181b" />
  <path d="M185,220 Q200,235 215,220" stroke="%23c2410c" stroke-width="3" fill="none" stroke-linecap="round" />
  <rect x="100" y="350" width="200" height="36" rx="18" fill="%23c2410c" stroke="%23fb923c" stroke-width="2" />
  <text x="200" y="373" font-family="sans-serif" font-weight="900" font-size="13" fill="%23ffffff" text-anchor="middle">THẦY TRÍ • VẬT LÍ</text>
</svg>`;

export const GV07_AVATAR_SVG = `data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 400 400" width="100%" height="100%">
  <defs>
    <linearGradient id="bgGrad7" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="%23831843" />
      <stop offset="100%" stop-color="%23db2777" />
    </linearGradient>
    <linearGradient id="skinGrad7" x1="0%" y1="0%" x2="0%" y2="100%">
      <stop offset="0%" stop-color="%23fed7aa" />
      <stop offset="100%" stop-color="%23fdba74" />
    </linearGradient>
  </defs>
  <rect width="400" height="400" rx="36" fill="url(%23bgGrad7)" />
  <circle cx="200" cy="180" r="140" fill="%23f472b6" opacity="0.15" />
  <path d="M110,380 L110,330 Q120,280 200,280 Q280,280 290,330 L290,380 Z" fill="%239d174d" stroke="%23fbcfe8" stroke-width="3" />
  <polygon points="175,280 200,325 225,280" fill="%23ffffff" />
  <rect x="182" y="240" width="36" height="50" rx="8" fill="url(%23skinGrad7)" />
  <ellipse cx="200" cy="180" rx="62" ry="72" fill="url(%23skinGrad7)" />
  <path d="M125,170 Q130,110 200,105 Q270,110 275,170 Z" fill="%23172554" />
  <circle cx="170" cy="175" r="5" fill="%23172554" />
  <circle cx="230" cy="175" r="5" fill="%23172554" />
  <path d="M182,215 Q200,235 218,215" stroke="%23db2777" stroke-width="3.5" fill="%23fce7f3" stroke-linecap="round" />
  <rect x="100" y="350" width="200" height="36" rx="18" fill="%23db2777" stroke="%23f472b6" stroke-width="2" />
  <text x="200" y="373" font-family="sans-serif" font-weight="900" font-size="13" fill="%23ffffff" text-anchor="middle">CÔ HÀ • VẬT LÍ</text>
</svg>`;

export const GV08_AVATAR_SVG = `data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 400 400" width="100%" height="100%">
  <defs>
    <linearGradient id="bgGrad8" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="%2314532d" />
      <stop offset="100%" stop-color="%2315803d" />
    </linearGradient>
    <linearGradient id="skinGrad8" x1="0%" y1="0%" x2="0%" y2="100%">
      <stop offset="0%" stop-color="%23fed7aa" />
      <stop offset="100%" stop-color="%23fcd34d" />
    </linearGradient>
  </defs>
  <rect width="400" height="400" rx="36" fill="url(%23bgGrad8)" />
  <circle cx="200" cy="180" r="140" fill="%234ade80" opacity="0.15" />
  <path d="M110,380 L110,330 Q120,280 200,280 Q280,280 290,330 L290,380 Z" fill="%23166534" stroke="%2386efac" stroke-width="3" />
  <polygon points="175,280 200,325 225,280" fill="%23ffffff" />
  <rect x="180" y="240" width="40" height="50" rx="8" fill="url(%23skinGrad8)" />
  <ellipse cx="200" cy="180" rx="65" ry="75" fill="url(%23skinGrad8)" />
  <path d="M130,165 Q135,105 200,105 Q265,105 270,165 Z" fill="%231f2937" />
  <circle cx="170" cy="178" r="5" fill="%231f2937" />
  <circle cx="230" cy="178" r="5" fill="%231f2937" />
  <path d="M185,220 Q200,235 215,220" stroke="%2315803d" stroke-width="3" fill="none" stroke-linecap="round" />
  <rect x="100" y="350" width="200" height="36" rx="18" fill="%2315803d" stroke="%234ade80" stroke-width="2" />
  <text x="200" y="373" font-family="sans-serif" font-weight="900" font-size="13" fill="%23ffffff" text-anchor="middle">THẦY HUY • SINH HỌC</text>
</svg>`;

export const GV09_AVATAR_SVG = `data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 400 400" width="100%" height="100%">
  <defs>
    <linearGradient id="bgGrad9" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="%23581c87" />
      <stop offset="100%" stop-color="%237e22ce" />
    </linearGradient>
    <linearGradient id="skinGrad9" x1="0%" y1="0%" x2="0%" y2="100%">
      <stop offset="0%" stop-color="%23fed7aa" />
      <stop offset="100%" stop-color="%23fdba74" />
    </linearGradient>
  </defs>
  <rect width="400" height="400" rx="36" fill="url(%23bgGrad9)" />
  <circle cx="200" cy="180" r="140" fill="%23c084fc" opacity="0.15" />
  <path d="M110,380 L110,330 Q120,280 200,280 Q280,280 290,330 L290,380 Z" fill="%236b21a8" stroke="%23d8b4fe" stroke-width="3" />
  <polygon points="175,280 200,325 225,280" fill="%23ffffff" />
  <rect x="182" y="240" width="36" height="50" rx="8" fill="url(%23skinGrad9)" />
  <ellipse cx="200" cy="180" rx="62" ry="72" fill="url(%23skinGrad9)" />
  <path d="M125,170 Q130,110 200,105 Q270,110 275,170 Z" fill="%233b0764" />
  <circle cx="170" cy="175" r="5" fill="%233b0764" />
  <circle cx="230" cy="175" r="5" fill="%233b0764" />
  <path d="M182,215 Q200,235 218,215" stroke="%237e22ce" stroke-width="3.5" fill="%23f3e8ff" stroke-linecap="round" />
  <rect x="100" y="350" width="200" height="36" rx="18" fill="%237e22ce" stroke="%23c084fc" stroke-width="2" />
  <text x="200" y="373" font-family="sans-serif" font-weight="900" font-size="13" fill="%23ffffff" text-anchor="middle">CÔ LAN • HÓA HỌC</text>
</svg>`;

export const GV10_AVATAR_SVG = `data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 400 400" width="100%" height="100%">
  <defs>
    <linearGradient id="bgGrad10" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="%230f172a" />
      <stop offset="100%" stop-color="%23334155" />
    </linearGradient>
    <linearGradient id="skinGrad10" x1="0%" y1="0%" x2="0%" y2="100%">
      <stop offset="0%" stop-color="%23fed7aa" />
      <stop offset="100%" stop-color="%23fcd34d" />
    </linearGradient>
  </defs>
  <rect width="400" height="400" rx="36" fill="url(%23bgGrad10)" />
  <circle cx="200" cy="180" r="140" fill="%2394a3b8" opacity="0.15" />
  <path d="M110,380 L110,330 Q120,280 200,280 Q280,280 290,330 L290,380 Z" fill="%231e293b" stroke="%23cbd5e1" stroke-width="3" />
  <polygon points="175,280 200,325 225,280" fill="%23ffffff" />
  <rect x="180" y="240" width="40" height="50" rx="8" fill="url(%23skinGrad10)" />
  <ellipse cx="200" cy="180" rx="65" ry="75" fill="url(%23skinGrad10)" />
  <path d="M130,165 Q135,105 200,105 Q265,105 270,165 Z" fill="%230f172a" />
  <circle cx="170" cy="178" r="5" fill="%230f172a" />
  <circle cx="230" cy="178" r="5" fill="%230f172a" />
  <path d="M185,220 Q200,235 215,220" stroke="%23475569" stroke-width="3" fill="none" stroke-linecap="round" />
  <rect x="100" y="350" width="200" height="36" rx="18" fill="%23334155" stroke="%2394a3b8" stroke-width="2" />
  <text x="200" y="373" font-family="sans-serif" font-weight="900" font-size="13" fill="%23ffffff" text-anchor="middle">THẦY ĐẠT • VẬT LÍ</text>
</svg>`;

/**
 * 10 Official Teachers for Round 2 Question Bank:
 * GV01 -> GV10
 */
export const tenOfficialTeachers: Teacher[] = [
  {
    id: 'GV01',
    round: 2,
    name: 'NGUYEN MINH TIEN',
    displayName: 'Thầy Tiến',
    subject: 'HOA HOC',
    department: 'Tổ Khoa học Tự nhiên Pétrus Ký',
    grades: '10, 11, 12',
    homeroom: '11.1',
    characteristics: 'DOC TOAN THAN, DA TAI',
    image: GV01_AVATAR_SVG,
    clues: [
      'Nơi những phản ứng, chất và thế giới phân tử trở thành những câu chuyện đầy bất ngờ.',
      'Nhân vật này có thể đồng hành cùng học sinh ở cả ba khối của THPT.',
      'Nhân vật này không chỉ có một "hệ kỹ năng" — càng khám phá càng thấy nhiều tài lẻ.',
      'Trang phục lịch lãm với áo sơ mi, cà vạt xanh và cặp kính cận tri thức tỏa sáng.',
    ],
    clueAnswers: ['hoa hoc', '10,11,12', 'doc toan than', 'ca vat'],
    clueAcceptedAnswers: [
      ['hoa hoc', 'hoahoc'],
      ['10,11,12', '10 11 12'],
      ['doc toan than', 'da tai'],
      ['ca vat', 'kinh'],
    ],
    options: ['Thầy Nguyễn Minh Tiến', 'Thầy Lê Quang Đạt', 'Thầy Trần Đình Trí', 'Thầy Hoàng Minh Vũ'],
    correctAnswer: 'NGUYEN MINH TIEN',
    points: 100,
    timeLimit: 90,
    active: true,
  },
  {
    id: 'GV02',
    round: 2,
    name: 'LE THI MY THAM',
    displayName: 'Cô Thẩm',
    subject: 'VAT LI',
    department: 'Tổ Khoa học Tự nhiên Pétrus Ký',
    grades: '11, 12',
    homeroom: '11.4',
    characteristics: '2 EM BE SIU QUAY',
    image: GV02_AVATAR_SVG,
    clues: [
      'Những định luật, chuyển động, năng lượng và các hiện tượng tự nhiên là lãnh địa quen thuộc của nhân vật này.',
      'Nhân vật này thường đồng hành cùng những lớp đang bước vào các chương quan trọng của THPT.',
      'Ở nhà, nhân vật này có hai "trợ lý nhí" luôn mang đến những pha bất ngờ và nguồn năng lượng không giới hạn.',
      'Mái tóc dài thướt tha, trang phục màu xanh ngọc quý phái cùng nụ cười rạng ngời.',
    ],
    clueAnswers: ['vat li', '11,12', '2 em be sieu quay', 'toc dai'],
    clueAcceptedAnswers: [
      ['vat li', 'vatly'],
      ['11,12', '11 12'],
      ['2 em be sieu quay', '2 em be'],
      ['toc dai', 'trang phuc mau xanh'],
    ],
    options: ['Cô Lê Thị Mỹ Thẩm', 'Cô Nguyễn Phương Thảo', 'Cô Đỗ Mai Lan', 'Cô Lê Thảo Trang'],
    correctAnswer: 'LE THI MY THAM',
    points: 100,
    timeLimit: 90,
    active: true,
  },
  {
    id: 'GV03',
    round: 2,
    name: 'LE THI HONG MAI',
    displayName: 'Cô Mai',
    subject: 'HOA HOC',
    department: 'Tổ Khoa học Tự nhiên Pétrus Ký',
    grades: '11, 12',
    homeroom: 'KHONG CHU NHIEM',
    characteristics: 'TIKTOKER',
    image: GV03_AVATAR_SVG,
    clues: [
      'Những phản ứng, chất và biến đổi của vật chất là một phần quen thuộc trong thế giới của nhân vật này.',
      'Nhân vật này thường đồng hành cùng học sinh ở hai khối cuối cấp của chương trình THPT.',
      'Không chỉ xuất hiện trong lớp học, nhân vật này còn khá quen thuộc với thế giới video ngắn.',
      'Cặp kính tròn thời trang cực chất, mái tóc năng động cá tính và phong cách rực rỡ.',
    ],
    clueAnswers: ['hoa hoc', '11,12', 'tiktoker', 'kinh tron'],
    clueAcceptedAnswers: [
      ['hoa hoc', 'hoahoc'],
      ['11,12', '11 12'],
      ['tiktoker', 'tik tok', 'tiktok'],
      ['kinh tron', 'kinh'],
    ],
    options: ['Cô Lê Thị Hồng Mai', 'Cô Vũ Thị Thu Hà', 'Cô Phan Khánh Linh', 'Cô Hoàng Yến Nhi'],
    correctAnswer: 'LE THI HONG MAI',
    points: 100,
    timeLimit: 90,
    active: true,
  },
  {
    id: 'GV04',
    round: 2,
    name: 'NGUYEN TRONG KHOA',
    displayName: 'Thầy Khoa',
    subject: 'SINH HOC',
    department: 'Tổ Khoa học Tự nhiên Pétrus Ký',
    grades: '10, 11',
    homeroom: '10.2',
    characteristics: 'YÊU THIÊN NHIÊN, TRẦM TÍNH',
    image: GV04_AVATAR_SVG,
    clues: [
      'Thế giới vi sinh vật, di truyền học và tế bào sống là đam mê lớn nhất của thầy.',
      'Thầy thường đứng lớp ở các khối lớp đầu cấp THPT với phương pháp sinh động.',
      'Thầy rất thích trồng cây cảnh và sưu tầm tiêu bản thực vật quý hiếm.',
      'Gương mặt điềm tĩnh, áo sơ mi màu xanh lá lục và cặp kính cận mạ kim loại.',
    ],
    clueAnswers: ['sinh hoc', '10,11', 'yeu thien nhien', 'ao xanh la'],
    clueAcceptedAnswers: [
      ['sinh hoc', 'sinh'],
      ['10,11', '10 11'],
      ['yeu thien nhien', 'tram tinh'],
      ['ao xanh la', 'kinh can'],
    ],
    options: ['Thầy Nguyễn Trọng Khoa', 'Thầy Phạm Gia Huy', 'Thầy Lê Quang Đạt', 'Thầy Hoàng Minh Vũ'],
    correctAnswer: 'NGUYEN TRONG KHOA',
    points: 100,
    timeLimit: 90,
    active: true,
  },
  {
    id: 'GV05',
    round: 2,
    name: 'NGUYEN PHUONG THAO',
    displayName: 'Cô Thảo',
    subject: 'HOA HOC',
    department: 'Tổ Khoa học Tự nhiên Pétrus Ký',
    grades: '10, 12',
    homeroom: '12.3',
    characteristics: 'SIÊU NHIỆT TÌNH, NỤ CƯỜI TỎA NẮNG',
    image: GV05_AVATAR_SVG,
    clues: [
      'Cô dẫn dắt học sinh chinh phục bảng tuần hoàn và các phương trình hữu cơ phức tạp.',
      'Được các học sinh khối 10 và 12 vô cùng yêu quý vì sự tận tâm chu đáo.',
      'Luôn là người khuấy động phong trào văn nghệ và các hội thi khoa học của trường.',
      'Trang phục áo dài tím than thanh lịch, mái tóc dài uốn lượn nữ tính.',
    ],
    clueAnswers: ['hoa hoc', '10,12', 'sieu nhiet tinh', 'toc dai'],
    clueAcceptedAnswers: [
      ['hoa hoc', 'hoa'],
      ['10,12', '10 12'],
      ['sieu nhiet tinh', 'nu cuoi toa nang'],
      ['ao tim', 'toc dai'],
    ],
    options: ['Cô Nguyễn Phương Thảo', 'Cô Đỗ Mai Lan', 'Cô Lê Thảo Trang', 'Cô Lê Thị Mỹ Thẩm'],
    correctAnswer: 'NGUYEN PHUONG THAO',
    points: 100,
    timeLimit: 90,
    active: true,
  },
  {
    id: 'GV06',
    round: 2,
    name: 'TRAN DINH TRI',
    displayName: 'Thầy Trí',
    subject: 'VAT LI',
    department: 'Tổ Khoa học Tự nhiên Pétrus Ký',
    grades: '11, 12',
    homeroom: '12.1',
    characteristics: 'BẬC THẦY THÍ NGHIỆM, VUI TÍNH',
    image: GV06_AVATAR_SVG,
    clues: [
      'Thầy có những bài giảng về mạch dao động điện từ và sóng cơ cực kỳ lôi cuốn.',
      'Thường rèn luyện cho các lớp khối 11 và 12 chuẩn bị cho kỳ thi tốt nghiệp.',
      'Phòng thực hành Vật lý luôn rộn rã tiếng cười trong mỗi tiết học của thầy.',
      'Phong cách đĩnh đạc, áo sơ mi màu cam đất cá tính và ánh mắt tinh anh.',
    ],
    clueAnswers: ['vat li', '11,12', 'bac thay thi nghiem', 'ao cam dat'],
    clueAcceptedAnswers: [
      ['vat li', 'vat ly'],
      ['11,12', '11 12'],
      ['bac thay thi nghiem', 'vui tinh'],
      ['ao cam', 'ao cam dat'],
    ],
    options: ['Thầy Trần Đình Trí', 'Thầy Lê Quang Đạt', 'Thầy Nguyễn Minh Tiến', 'Thầy Hoàng Minh Vũ'],
    correctAnswer: 'TRAN DINH TRI',
    points: 100,
    timeLimit: 90,
    active: true,
  },
  {
    id: 'GV07',
    round: 2,
    name: 'VU THI THU HA',
    displayName: 'Cô Hà',
    subject: 'VAT LI',
    department: 'Tổ Khoa học Tự nhiên Pétrus Ký',
    grades: '10, 11',
    homeroom: '10.4',
    characteristics: 'DỊU DÀNG, YÊU THƠ CA',
    image: GV07_AVATAR_SVG,
    clues: [
      'Cô giải thích hiện tượng quang học và khúc xạ ánh sáng mềm mại như một vần thơ.',
      'Đồng hành cùng học sinh khối 10 và 11 trên con đường làm quen với Vật lý THPT.',
      'Thường lồng ghép những câu đố vui thơ lục bát vào bài kiểm tra 15 phút.',
      'Mái tóc ngắn ôm gương mặt tròn phúc hậu, trang phục màu hồng cánh sen quý phái.',
    ],
    clueAnswers: ['vat li', '10,11', 'diu dang', 'ao hong'],
    clueAcceptedAnswers: [
      ['vat li', 'vat ly'],
      ['10,11', '10 11'],
      ['diu dang', 'yeu tho ca'],
      ['ao hong', 'toc ngan'],
    ],
    options: ['Cô Vũ Thị Thu Hà', 'Cô Nguyễn Thu Hà', 'Cô Phan Khánh Linh', 'Cô Lê Thị Mỹ Thẩm'],
    correctAnswer: 'VU THI THU HA',
    points: 100,
    timeLimit: 90,
    active: true,
  },
  {
    id: 'GV08',
    round: 2,
    name: 'PHAM GIA HUY',
    displayName: 'Thầy Huy',
    subject: 'SINH HOC',
    department: 'Tổ Khoa học Tự nhiên Pétrus Ký',
    grades: '11, 12',
    homeroom: '11.3',
    characteristics: 'TRẺ TRUNG, SAY MÊ CÔNG NGHỆ GEN',
    image: GV08_AVATAR_SVG,
    clues: [
      'Chuyên gia giải mã các quy luật Menđen và bản đồ di truyền phân tử tế bào.',
      'Thầy gắn bó mật thiết với học sinh hai khối lớn chuẩn bị thi học sinh giỏi.',
      'Người phụ trách dàn máy chiếu và phần mềm mô phỏng 3D sinh học của trường.',
      'Nụ cười thân thiện, áo sơ mi xanh lá tươi sáng và đồng hồ thông minh hiện đại.',
    ],
    clueAnswers: ['sinh hoc', '11,12', 'tre trung', 'ao xanh la'],
    clueAcceptedAnswers: [
      ['sinh hoc', 'sinh'],
      ['11,12', '11 12'],
      ['tre trung', 'say me cong nghe gen'],
      ['ao xanh la', 'dong ho'],
    ],
    options: ['Thầy Phạm Gia Huy', 'Thầy Nguyễn Trọng Khoa', 'Thầy Bùi Hoàng Nam', 'Thầy Ngô Văn Lâm'],
    correctAnswer: 'PHAM GIA HUY',
    points: 100,
    timeLimit: 90,
    active: true,
  },
  {
    id: 'GV09',
    round: 2,
    name: 'DO MAI LAN',
    displayName: 'Cô Lan',
    subject: 'HOA HOC',
    department: 'Tổ Khoa học Tự nhiên Pétrus Ký',
    grades: '10, 11, 12',
    homeroom: '10.1',
    characteristics: 'TẬN TÂM, NẮM RÕ TỪNG PHÂN TỬ',
    image: GV09_AVATAR_SVG,
    clues: [
      'Cô sở hữu phương pháp ghi nhớ hóa trị và tính chất kim loại bằng âm nhạc.',
      'Cô có thể dạy học sinh ở cả 3 khối 10, 11 và 12 của trường.',
      'Chủ nhiệm câu lạc bộ Sáng tạo trẻ và chế tạo xà phòng hữu cơ từ dầu ăn thừa.',
      'Trang phục màu tím hoa cà trang nhã, giọng nói ấm áp và nụ cười hiền từ.',
    ],
    clueAnswers: ['hoa hoc', '10,11,12', 'tan tam', 'ao tim hoa ca'],
    clueAcceptedAnswers: [
      ['hoa hoc', 'hoa'],
      ['10,11,12', '10 11 12'],
      ['tan tam', 'nam ro tung phan tu'],
      ['ao tim', 'ao tim hoa ca'],
    ],
    options: ['Cô Đỗ Mai Lan', 'Cô Nguyễn Phương Thảo', 'Cô Lê Thị Hồng Mai', 'Cô Lê Thảo Trang'],
    correctAnswer: 'DO MAI LAN',
    points: 100,
    timeLimit: 90,
    active: true,
  },
  {
    id: 'GV10',
    round: 2,
    name: 'LE QUANG DAT',
    displayName: 'Thầy Đạt',
    subject: 'VAT LI',
    department: 'Tổ Khoa học Tự nhiên Pétrus Ký',
    grades: '10, 12',
    homeroom: '12.2',
    characteristics: 'THỂ THAO, BẮN TÊN LỬA NƯỚC',
    image: GV10_AVATAR_SVG,
    clues: [
      'Thầy thường dùng máy bắn bóng và tên lửa nước để minh họa định luật Newton.',
      'Thầy phụ trách giảng dạy Vật lý cho khối 10 mới vào trường và khối 12 ôn thi.',
      'Huấn luyện viên đội bóng rổ nam của trường Pétrus Ký.',
      'Dáng người cao ráo thể thao, áo thun polo xám than năng động khỏe khoắn.',
    ],
    clueAnswers: ['vat li', '10,12', 'the thao', 'ao xam than'],
    clueAcceptedAnswers: [
      ['vat li', 'vat ly'],
      ['10,12', '10 12'],
      ['the thao', 'ban ten lua nuoc'],
      ['ao xam', 'ao polo'],
    ],
    options: ['Thầy Lê Quang Đạt', 'Thầy Trần Đình Trí', 'Thầy Hoàng Minh Vũ', 'Thầy Nguyễn Minh Tiến'],
    correctAnswer: 'LE QUANG DAT',
    points: 100,
    timeLimit: 90,
    active: true,
  },
];
