/**
 * PEK SCIENCE QUEST - THE FINAL CODE
 * Full-Stack MVP Interactive Science Escape Room Game
 * Organized by Tổ Khoa học Tự nhiên – Trường PeK
 */

import React, { useState, useEffect } from 'react';
import { Team, ActiveTab } from './types';
import { storageService } from './services/storageService';
import { GameEngine } from './services/gameEngine';
import { ParticleBackground } from './components/ParticleBackground';
import { Navbar } from './components/Navbar';

// Player Features
import { CheckIn } from './features/player/CheckIn';
import { MissionBriefing } from './features/player/MissionBriefing';
import { Round1View } from './features/player/Round1View';
import { Round2View } from './features/player/Round2View';
import { Round3View } from './features/player/Round3View';
import { Round4View } from './features/player/Round4View';
import { ResultsView } from './features/player/ResultsView';

// Leaderboard & Admin Features
import { LeaderboardView } from './features/leaderboard/LeaderboardView';
import { AdminDashboard } from './features/admin/AdminDashboard';
import { TreasureQuestModal } from './components/TreasureQuestModal';

export default function App() {
  const [currentTeam, setCurrentTeam] = useState<Team | null>(null);
  const [activeTab, setActiveTab] = useState<ActiveTab>('player');
  const [playerSubView, setPlayerSubView] = useState<'game' | 'leaderboard'>('game');
  const [questTransition, setQuestTransition] = useState<{
    isOpen: boolean;
    completedRound: 1 | 2 | 3 | 4;
    roundScore: number;
  } | null>(null);

  // Load and subscribe to team session
  const refreshTeam = () => {
    const team = storageService.getCurrentTeam();
    setCurrentTeam(team ? { ...team } : null);
  };

  useEffect(() => {
    // 1. Check URL parameters for direct multi-device team link (e.g. ?team=PEK-7F29 or ?code=PEK-7F29)
    if (typeof window !== 'undefined') {
      const urlParams = new URLSearchParams(window.location.search);
      const queryCode =
        urlParams.get('code') ||
        urlParams.get('team') ||
        urlParams.get('teamCode') ||
        urlParams.get('teamId');

      if (queryCode) {
        const clean = queryCode.trim().toUpperCase();
        const teams = storageService.getTeams();
        const found = teams.find(
          (t) => t.teamCode.toUpperCase() === clean || t.id.toUpperCase() === clean
        );
        if (found) {
          storageService.setCurrentTeamId(found.id);
          setCurrentTeam(found);
        } else {
          refreshTeam();
        }
      } else {
        refreshTeam();
      }
    } else {
      refreshTeam();
    }

    const unsub = storageService.subscribe((event) => {
      if (
        event.type === 'CURRENT_TEAM_CHANGED' ||
        event.type === 'TEAMS_UPDATED' ||
        event.type === 'FACTORY_RESET'
      ) {
        refreshTeam();
      }
    });
    return () => unsub();
  }, []);

  // Handlers for Round transitions with Treasure Quest Cutscenes
  const handleCheckInSuccess = (team: Team) => {
    setCurrentTeam(team);
    setPlayerSubView('game');
  };

  const handleStartRound1 = () => {
    if (!currentTeam) return;
    const updated: Team = {
      ...currentTeam,
      status: 'playing',
      currentRound: 1,
    };
    storageService.saveTeam(updated);
    setCurrentTeam(updated);
  };

  const handleRound1Complete = () => {
    if (!currentTeam) return;
    setQuestTransition({
      isOpen: true,
      completedRound: 1,
      roundScore: currentTeam.roundScores[1] || 0,
    });
  };

  const handleRound2Complete = () => {
    if (!currentTeam) return;
    setQuestTransition({
      isOpen: true,
      completedRound: 2,
      roundScore: currentTeam.roundScores[2] || 0,
    });
  };

  const handleRound3Complete = () => {
    if (!currentTeam) return;
    setQuestTransition({
      isOpen: true,
      completedRound: 3,
      roundScore: currentTeam.roundScores[3] || 0,
    });
  };

  const handleFinishGame = () => {
    if (!currentTeam) return;
    setQuestTransition({
      isOpen: true,
      completedRound: 4,
      roundScore: currentTeam.roundScores[4] || 0,
    });
  };

  const handleContinueAfterQuest = () => {
    if (!currentTeam || !questTransition) return;
    const updated = GameEngine.advanceRound(currentTeam);
    setCurrentTeam(updated);
    setQuestTransition(null);
  };

  const handleExitTeam = () => {
    storageService.setCurrentTeamId(null);
    setCurrentTeam(null);
    setPlayerSubView('game');
    setQuestTransition(null);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-sky-50 via-white to-indigo-50/70 text-slate-800 flex flex-col relative selection:bg-sky-500 selection:text-white">
      {/* Sci-fi Particle Grid Background */}
      <ParticleBackground />

      {/* Main Top Navigation */}
      <Navbar
        currentTeam={currentTeam}
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        onExitTeam={handleExitTeam}
      />

      {/* Main Content Area */}
      <main className="flex-1 relative z-10">
        {activeTab === 'admin' ? (
          /* ==================== GAME MASTER / ADMIN VIEW ==================== */
          <AdminDashboard />
        ) : (
          /* ==================== PLAYER VIEW ==================== */
          <div className="w-full">
            {playerSubView === 'leaderboard' ? (
              <div className="py-4">
                <div className="max-w-5xl mx-auto px-4 mb-4">
                  <button
                    onClick={() => setPlayerSubView('game')}
                    className="px-4 py-2 rounded-xl bg-slate-900 border border-slate-700 text-xs font-bold text-slate-300 hover:text-cyan-400 transition-all cursor-pointer"
                  >
                    ← Quay Lại Màn Hình Nhiệm Vụ
                  </button>
                </div>
                <LeaderboardView highlightTeamId={currentTeam?.id} />
              </div>
            ) : !currentTeam ? (
              /* Step 1: Check-in / Resume session */
              <CheckIn onCheckInSuccess={handleCheckInSuccess} />
            ) : currentTeam.status === 'ready' ? (
              /* Step 2: Mission Briefing */
              <MissionBriefing team={currentTeam} onStartRound1={handleStartRound1} />
            ) : currentTeam.status === 'finished' ? (
              /* Step 4: Finished -> Results & Honors */
              <ResultsView
                team={currentTeam}
                onViewLeaderboard={() => setPlayerSubView('leaderboard')}
                onPlayAgain={handleExitTeam}
              />
            ) : (
              /* Step 3: Game Rounds 1 to 4 */
              <div>
                {currentTeam.currentRound === 1 && (
                  <Round1View team={currentTeam} onRoundComplete={handleRound1Complete} />
                )}
                {currentTeam.currentRound === 2 && (
                  <Round2View team={currentTeam} onRoundComplete={handleRound2Complete} />
                )}
                {currentTeam.currentRound === 3 && (
                  <Round3View team={currentTeam} onRoundComplete={handleRound3Complete} />
                )}
                {currentTeam.currentRound === 4 && (
                  <Round4View team={currentTeam} onFinishGame={handleFinishGame} />
                )}
              </div>
            )}
          </div>
        )}
      </main>

      {/* Treasure Quest Cutscene Transition Modal */}
      {questTransition && questTransition.isOpen && currentTeam && (
        <TreasureQuestModal
          completedRound={questTransition.completedRound}
          teamName={currentTeam.teamName}
          roundScore={questTransition.roundScore}
          onContinue={handleContinueAfterQuest}
        />
      )}

      {/* Footer */}
      <footer className="border-t border-slate-900 bg-slate-950/80 py-4 text-center text-xs text-slate-500 font-mono relative z-10">
        <p>
          PEK SCIENCE QUEST • THE FINAL CODE © {new Date().getFullYear()} Tổ Khoa học Tự nhiên Trường Pétrus Ký
        </p>
      </footer>
    </div>
  );
}
