import React, { useState, useEffect } from 'react';
import {
  Trophy,
  Medal,
  Clock,
  Search,
  Filter,
  Users,
  Sparkles,
  ArrowUpDown,
  RefreshCw,
  UserCheck,
} from 'lucide-react';
import { Team } from '../../types';
import { ScoringEngine } from '../../services/scoringEngine';
import { storageService } from '../../services/storageService';

interface LeaderboardViewProps {
  highlightTeamId?: string;
  isProjectorMode?: boolean;
}

export const LeaderboardView: React.FC<LeaderboardViewProps> = ({
  highlightTeamId,
  isProjectorMode = false,
}) => {
  const [teams, setTeams] = useState<Team[]>([]);
  const [searchTerm, setSearchTerm] = useState<string>('');
  const [statusFilter, setStatusFilter] = useState<'all' | 'playing' | 'finished'>('all');

  const loadTeams = () => {
    const list = storageService.getTeams();
    const sorted = [...list].sort(ScoringEngine.compareTeams);
    setTeams(sorted);
  };

  useEffect(() => {
    loadTeams();
    const unsubscribe = storageService.subscribe((event) => {
      if (event.type === 'TEAMS_UPDATED' || event.type === 'FACTORY_RESET') {
        loadTeams();
      }
    });
    return () => unsubscribe();
  }, []);

  const filteredTeams = teams.filter((t) => {
    const matchSearch =
      t.teamName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      t.className.toLowerCase().includes(searchTerm.toLowerCase()) ||
      t.teamCode.toLowerCase().includes(searchTerm.toLowerCase()) ||
      (t.captainName && t.captainName.toLowerCase().includes(searchTerm.toLowerCase()));

    if (!matchSearch) return false;
    if (statusFilter === 'playing') return t.status === 'playing' || t.status === 'ready';
    if (statusFilter === 'finished') return t.status === 'finished';
    return true;
  });

  const getRankBadge = (rank: number) => {
    if (rank === 1) {
      return (
        <span className="inline-flex items-center justify-center w-8 h-8 rounded-full bg-gradient-to-tr from-yellow-400 to-amber-400 text-slate-950 font-black text-sm shadow-md shadow-yellow-400/40">
          <Trophy className="w-4 h-4 stroke-[2.5]" />
        </span>
      );
    }
    if (rank === 2) {
      return (
        <span className="inline-flex items-center justify-center w-8 h-8 rounded-full bg-gradient-to-tr from-slate-200 to-slate-300 text-slate-800 font-black text-sm shadow-sm border border-slate-300">
          <Medal className="w-4 h-4 stroke-[2.5]" />
        </span>
      );
    }
    if (rank === 3) {
      return (
        <span className="inline-flex items-center justify-center w-8 h-8 rounded-full bg-gradient-to-tr from-amber-600 to-amber-700 text-white font-black text-sm shadow-sm">
          <Medal className="w-4 h-4 stroke-[2.5]" />
        </span>
      );
    }
    return (
      <span className="inline-flex items-center justify-center w-8 h-8 rounded-full bg-slate-100 text-slate-600 font-mono font-bold text-xs border border-slate-200">
        #{rank}
      </span>
    );
  };

  const getStatusBadge = (status: Team['status'], round: Team['currentRound']) => {
    if (status === 'finished') {
      return (
        <span className="px-2.5 py-1 rounded-full text-[11px] font-bold bg-emerald-100 text-emerald-800 border border-emerald-300">
          Hoàn thành
        </span>
      );
    }
    return (
      <span className="px-2.5 py-1 rounded-full text-[11px] font-bold bg-sky-100 text-sky-800 border border-sky-300 font-mono">
        Vòng {round}/4
      </span>
    );
  };

  return (
    <div className={`max-w-6xl mx-auto px-4 py-6 sm:py-10 ${isProjectorMode ? 'max-w-full' : ''}`}>
      {/* Top 3 Podium Cards */}
      {teams.length >= 3 && (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8 items-end">
          {/* Rank 2 (Silver) */}
          <div className="bg-white border-2 border-slate-200 rounded-3xl p-5 text-center shadow-lg relative order-2 md:order-1 flex flex-col items-center">
            <div className="w-10 h-10 rounded-full bg-slate-200 text-slate-700 font-black flex items-center justify-center text-sm mb-2 shadow-sm">
              <Medal className="w-5 h-5" />
            </div>
            <span className="text-[10px] font-mono font-bold text-slate-500 uppercase tracking-wider">
              Á QUÂN (HẠNG 2)
            </span>
            <h3 className="font-black text-base text-slate-900 truncate max-w-full mt-1">
              {teams[1].teamName}
            </h3>
            <span className="text-xs text-sky-700 bg-sky-50 px-2 py-0.5 rounded font-mono font-bold mt-0.5">
              {teams[1].className}
            </span>
            {teams[1].captainName && (
              <p className="text-[11px] text-slate-500 mt-1">
                Đội trưởng: <strong>{teams[1].captainName}</strong>
              </p>
            )}
            <span className="text-lg sm:text-xl font-black text-slate-900 font-mono mt-2">
              {teams[1].score} pts
            </span>
          </div>

          {/* Rank 1 (Gold Champion) */}
          <div className="bg-gradient-to-b from-amber-50 to-white border-2 border-amber-300 rounded-3xl p-6 text-center shadow-xl relative order-1 md:order-2 flex flex-col items-center md:-translate-y-4">
            <div className="w-14 h-14 rounded-2xl bg-gradient-to-tr from-yellow-400 to-amber-500 text-slate-950 font-black flex items-center justify-center shadow-lg shadow-amber-400/30 mb-2 animate-bounce-gentle">
              <Trophy className="w-7 h-7 stroke-[2.5]" />
            </div>
            <span className="text-[11px] font-mono font-bold text-amber-700 uppercase tracking-widest bg-amber-100 px-3 py-0.5 rounded-full border border-amber-300">
              QUÁN QUÂN NEXT GEN (HẠNG 1)
            </span>
            <h3 className="font-black text-xl text-slate-900 truncate max-w-full mt-2">
              {teams[0].teamName}
            </h3>
            <span className="text-xs text-sky-800 bg-sky-100 px-2.5 py-0.5 rounded-full font-mono font-bold mt-1">
              {teams[0].className} • Mã: {teams[0].teamCode}
            </span>
            {teams[0].captainName && (
              <p className="text-xs text-indigo-700 font-semibold mt-1 flex items-center gap-1">
                <UserCheck className="w-3.5 h-3.5" />
                <span>Đội trưởng: <strong>{teams[0].captainName}</strong></span>
              </p>
            )}
            <span className="text-2xl sm:text-3xl font-black text-amber-700 font-mono mt-2">
              {teams[0].score} pts
            </span>
          </div>

          {/* Rank 3 (Bronze) */}
          <div className="bg-white border-2 border-amber-200 rounded-3xl p-5 text-center shadow-lg relative order-3 flex flex-col items-center">
            <div className="w-10 h-10 rounded-full bg-amber-700 text-white font-black flex items-center justify-center text-sm mb-2 shadow-sm">
              <Medal className="w-5 h-5" />
            </div>
            <span className="text-[10px] font-mono font-bold text-amber-700 uppercase tracking-wider">
              QUÝ QUÂN (HẠNG 3)
            </span>
            <h3 className="font-black text-base text-slate-900 truncate max-w-full mt-1">
              {teams[2].teamName}
            </h3>
            <span className="text-xs text-sky-700 bg-sky-50 px-2 py-0.5 rounded font-mono font-bold mt-0.5">
              {teams[2].className}
            </span>
            {teams[2].captainName && (
              <p className="text-[11px] text-slate-500 mt-1">
                Đội trưởng: <strong>{teams[2].captainName}</strong>
              </p>
            )}
            <span className="text-lg sm:text-xl font-black text-amber-800 font-mono mt-2">
              {teams[2].score} pts
            </span>
          </div>
        </div>
      )}

      {/* Header and Title */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <Trophy className="w-5 h-5 text-amber-500" />
            <span className="text-xs font-mono font-bold text-amber-600 uppercase tracking-widest">
              BẢNG TỔNG SẮP DANH DỰ • NEXT GEN
            </span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-black text-slate-900 tracking-tight">
            LEADERBOARD PEK SCIENCE QUEST
          </h1>
        </div>

        {/* Search & Refresh */}
        <div className="flex items-center gap-3">
          <div className="relative">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-3 pointer-events-none" />
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="Tìm theo đội, lớp, đội trưởng..."
              className="bg-white border border-slate-200 rounded-xl pl-9 pr-4 py-2 text-xs text-slate-800 placeholder-slate-400 outline-none w-48 sm:w-64 focus:border-sky-500 transition-all shadow-sm"
            />
          </div>

          <button
            onClick={loadTeams}
            title="Tải lại bảng xếp hạng"
            className="p-2.5 rounded-xl bg-white border border-slate-200 text-slate-600 hover:text-sky-600 hover:border-sky-400 transition-all cursor-pointer shadow-sm"
          >
            <RefreshCw className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Filter Tabs */}
      <div className="flex items-center gap-2 mb-6">
        <button
          onClick={() => setStatusFilter('all')}
          className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
            statusFilter === 'all'
              ? 'bg-sky-600 text-white font-black shadow-sm'
              : 'bg-white text-slate-600 hover:text-slate-900 border border-slate-200'
          }`}
        >
          Tất cả các đội ({teams.length})
        </button>
        <button
          onClick={() => setStatusFilter('finished')}
          className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
            statusFilter === 'finished'
              ? 'bg-emerald-600 text-white font-black shadow-sm'
              : 'bg-white text-slate-600 hover:text-slate-900 border border-slate-200'
          }`}
        >
          Đã hoàn thành ({teams.filter((t) => t.status === 'finished').length})
        </button>
        <button
          onClick={() => setStatusFilter('playing')}
          className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
            statusFilter === 'playing'
              ? 'bg-indigo-600 text-white font-black shadow-sm'
              : 'bg-white text-slate-600 hover:text-slate-900 border border-slate-200'
          }`}
        >
          Đang thi đấu ({teams.filter((t) => t.status !== 'finished').length})
        </button>
      </div>

      {/* Leaderboard Table Card - Bright & Crisp */}
      <div className="bg-white border border-slate-200 rounded-3xl overflow-hidden shadow-xl">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-slate-50 border-b border-slate-200 text-[11px] font-mono text-slate-600 uppercase tracking-wider">
                <th className="py-4 px-4 sm:px-6 w-16 text-center">Hạng</th>
                <th className="py-4 px-4">Tên Đội & Đội Trưởng</th>
                <th className="py-4 px-4 hidden md:table-cell">Mã Đội</th>
                <th className="py-4 px-4 text-center">Tiến Trình</th>
                <th className="py-4 px-4 text-right">Tổng Điểm</th>
                <th className="py-4 px-4 sm:px-6 text-right">Thời Gian</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-sm">
              {filteredTeams.length === 0 ? (
                <tr>
                  <td colSpan={6} className="py-12 text-center text-slate-400">
                    Chưa có đội nào phù hợp với bộ lọc hiện tại.
                  </td>
                </tr>
              ) : (
                filteredTeams.map((team, idx) => {
                  const isCurrent = team.id === highlightTeamId;
                  const rank = idx + 1;
                  return (
                    <tr
                      key={team.id}
                      className={`transition-colors ${
                        isCurrent
                          ? 'bg-sky-50 font-bold border-l-4 border-l-sky-500'
                          : 'hover:bg-slate-50/70'
                      }`}
                    >
                      {/* Rank */}
                      <td className="py-4 px-4 sm:px-6 text-center font-bold">
                        {getRankBadge(rank)}
                      </td>

                      {/* Team Name, Class & Captain */}
                      <td className="py-4 px-4">
                        <div className="flex items-center gap-2">
                          <span className="font-bold text-base text-slate-900">
                            {team.teamName}
                          </span>
                          <span className="text-xs bg-slate-100 text-slate-700 px-2 py-0.5 rounded font-mono border border-slate-200 font-semibold">
                            {team.className}
                          </span>
                        </div>
                        {team.captainName && (
                          <p className="text-xs text-indigo-700 mt-0.5 font-medium flex items-center gap-1">
                            <UserCheck className="w-3.5 h-3.5 text-indigo-500" />
                            <span>Đội trưởng: <strong className="text-indigo-900">{team.captainName}</strong></span>
                          </p>
                        )}
                      </td>

                      {/* Team Code */}
                      <td className="py-4 px-4 hidden md:table-cell font-mono text-xs text-sky-700 font-bold">
                        {team.teamCode}
                      </td>

                      {/* Status / Round */}
                      <td className="py-4 px-4 text-center">
                        {getStatusBadge(team.status, team.currentRound)}
                      </td>

                      {/* Score */}
                      <td className="py-4 px-4 text-right font-mono font-black text-lg text-amber-700">
                        {team.score}
                        <span className="text-[10px] text-slate-400 font-normal ml-1">pts</span>
                      </td>

                      {/* Time */}
                      <td className="py-4 px-4 sm:px-6 text-right font-mono text-slate-600 text-xs">
                        <div className="flex items-center justify-end gap-1.5">
                          <Clock className="w-3.5 h-3.5 text-slate-400" />
                          <span>{ScoringEngine.formatTime(team.elapsedTime)}</span>
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Arena Live Ticker Banner */}
      <div className="mt-6 p-4 bg-white border border-slate-200 rounded-2xl flex items-center gap-3 overflow-hidden text-xs shadow-sm">
        <span className="flex items-center gap-1.5 font-mono font-bold text-amber-800 bg-amber-100 px-2.5 py-1 rounded-lg border border-amber-300 uppercase whitespace-nowrap flex-shrink-0 animate-pulse">
          <Sparkles className="w-3.5 h-3.5 text-amber-600" />
          <span>TIN NÓNG ĐẤU TRƯỜNG:</span>
        </span>
        <div className="text-slate-600 font-medium truncate">
          {teams.length > 0 ? (
            <span>
              Đội <strong className="text-sky-700 font-bold">{teams[0].teamName} ({teams[0].className})</strong> đang tạm dẫn đầu bảng tổng sắp với {teams[0].score} điểm • {teams.filter((t) => t.status === 'finished').length}/{teams.length} đội đã mở khóa Rương Kho Báu Next Gen!
            </span>
          ) : (
            <span>Đấu trường sẵn sàng. Chào mừng các đội thi đến với PEK SCIENCE QUEST!</span>
          )}
        </div>
      </div>
    </div>
  );
};
