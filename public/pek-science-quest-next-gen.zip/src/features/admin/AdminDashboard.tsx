import React, { useState, useEffect } from 'react';
import {
  Users,
  Play,
  Pause,
  FastForward,
  Square,
  Trophy,
  Clock,
  Sparkles,
  Layers,
  Database,
  Tv,
  Settings,
  RefreshCw,
  Award,
  Radio,
  CheckCircle2,
  FileSpreadsheet,
  Printer,
  Gift,
  Lock,
  KeyRound,
  ShieldCheck,
  Download,
} from 'lucide-react';
import { Team, GameConfig, AdminTab } from '../../types';
import { storageService } from '../../services/storageService';
import { ScoringEngine } from '../../services/scoringEngine';
import { ExcelService } from '../../services/excelService';
import { TeamMonitor } from './TeamMonitor';
import { QuestionBankView } from './QuestionBankView';
import { MysteryCodesView } from './MysteryCodesView';
import { StationPrintModal } from './StationPrintModal';
import { SystemDiagnosticsView } from './SystemDiagnosticsView';
import { LeaderboardView } from '../leaderboard/LeaderboardView';
import { audioManager } from '../../services/audioManager';
import { ConfirmModal } from '../../components/ConfirmModal';

export const AdminDashboard: React.FC = () => {
  const [adminTab, setAdminTab] = useState<AdminTab>('dashboard');
  const [teams, setTeams] = useState<Team[]>([]);
  const [config, setConfig] = useState<GameConfig>(storageService.getGameConfig());
  const [showPrintStations, setShowPrintStations] = useState<boolean>(false);
  const [showEndGameConfirm, setShowEndGameConfirm] = useState<boolean>(false);

  const refreshAll = () => {
    const list = storageService.getTeams();
    setTeams([...list]);
    setConfig(storageService.getGameConfig());
  };

  useEffect(() => {
    refreshAll();
    const unsub = storageService.subscribe((event) => {
      if (
        event.type === 'TEAMS_UPDATED' ||
        event.type === 'CONFIG_UPDATED' ||
        event.type === 'FACTORY_RESET'
      ) {
        refreshAll();
      }
    });
    return () => unsub();
  }, []);

  // Compute Master KPIs
  const totalTeams = teams.length;
  const waitingTeams = teams.filter((t) => t.status === 'ready').length;
  const playingTeams = teams.filter((t) => t.status === 'playing').length;
  const completedTeams = teams.filter((t) => t.status === 'finished').length;

  const sortedTeams = [...teams].sort(ScoringEngine.compareTeams);
  const highestScoreTeam = sortedTeams[0];
  const finishedTeams = sortedTeams.filter((t) => t.status === 'finished');
  const bestTimeTeam = finishedTeams.length > 0 ? finishedTeams[0] : null;

  // Master Control Actions
  const handleStartGame = () => {
    const updated: GameConfig = { ...config, gameStatus: 'in_progress' };
    storageService.saveGameConfig(updated);
    audioManager.playUnlock();
  };

  const handlePauseGame = () => {
    const updated: GameConfig = { ...config, gameStatus: 'paused' };
    storageService.saveGameConfig(updated);
  };

  const handleResumeGame = () => {
    const updated: GameConfig = { ...config, gameStatus: 'in_progress' };
    storageService.saveGameConfig(updated);
    audioManager.playUnlock();
  };

  const handleNextRound = () => {
    if (config.globalCurrentRound < 4) {
      const nextR = (config.globalCurrentRound + 1) as 1 | 2 | 3 | 4;
      const updated: GameConfig = { ...config, globalCurrentRound: nextR };
      storageService.saveGameConfig(updated);
      audioManager.playUnlock();
    }
  };

  const handleEndGame = () => {
    setShowEndGameConfirm(true);
  };

  const confirmEndGameAction = () => {
    const updated: GameConfig = { ...config, gameStatus: 'completed' };
    storageService.saveGameConfig(updated);
    audioManager.playVictory();
    setShowEndGameConfirm(false);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-6 sm:py-8">
      {/* Top Banner - Bright & Crisp */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 mb-6 bg-white border border-slate-200 rounded-3xl p-6 shadow-xl">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="w-2.5 h-2.5 rounded-full bg-indigo-500 animate-ping" />
            <span className="text-xs font-mono font-bold text-indigo-700 uppercase tracking-widest">
              GAME MASTER COMMAND CENTER
            </span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-black text-slate-900 tracking-tight">
            ĐIỀU HÀNH GIẢI ĐẤU KHOA HỌC PEK
          </h1>
          <p className="text-xs text-slate-500 mt-1">
            Tổ Khoa học Tự nhiên • Giám sát thời gian thực & Quản trị hệ thống
          </p>
        </div>

        {/* Global Game Status & Quick Controls */}
        <div className="flex flex-wrap items-center gap-2">
          {config.gameStatus === 'waiting' && (
            <button
              onClick={handleStartGame}
              className="px-4 py-2.5 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-400 hover:to-teal-500 text-white font-bold text-xs flex items-center gap-1.5 shadow-md shadow-emerald-500/20 cursor-pointer"
            >
              <Play className="w-4 h-4 fill-current" />
              <span>BẮT ĐẦU GIẢI</span>
            </button>
          )}

          {config.gameStatus === 'in_progress' && (
            <button
              onClick={handlePauseGame}
              className="px-4 py-2.5 rounded-xl bg-amber-50 hover:bg-amber-100 border border-amber-300 text-amber-800 font-bold text-xs flex items-center gap-1.5 transition-all cursor-pointer"
            >
              <Pause className="w-4 h-4" />
              <span>TẠM DỪNG</span>
            </button>
          )}

          {config.gameStatus === 'paused' && (
            <button
              onClick={handleResumeGame}
              className="px-4 py-2.5 rounded-xl bg-sky-600 hover:bg-sky-500 text-white font-bold text-xs flex items-center gap-1.5 transition-all cursor-pointer shadow-md shadow-sky-600/25"
            >
              <Play className="w-4 h-4 fill-current" />
              <span>TIẾP TỤC GIẢI</span>
            </button>
          )}

          <button
            onClick={handleNextRound}
            disabled={config.globalCurrentRound >= 4}
            className={`px-4 py-2.5 rounded-xl border text-xs font-bold flex items-center gap-1.5 transition-all cursor-pointer ${
              config.globalCurrentRound < 4
                ? 'bg-indigo-50 hover:bg-indigo-100 border-indigo-300 text-indigo-800'
                : 'bg-slate-100 border-slate-200 text-slate-400 cursor-not-allowed'
            }`}
          >
            <FastForward className="w-4 h-4" />
            <span>Chuyển Vòng {Math.min(4, config.globalCurrentRound + 1)}</span>
          </button>

          <button
            onClick={handleEndGame}
            className="px-4 py-2.5 rounded-xl bg-rose-50 hover:bg-rose-100 border border-rose-200 text-rose-700 font-bold text-xs flex items-center gap-1.5 transition-all cursor-pointer"
          >
            <Square className="w-4 h-4 fill-current" />
            <span>KẾT THÚC</span>
          </button>

          <button
            onClick={() => ExcelService.exportTournamentReport(teams)}
            className="px-3.5 py-2.5 rounded-xl bg-emerald-50 hover:bg-emerald-100 border border-emerald-300 text-emerald-800 font-bold text-xs flex items-center gap-1.5 transition-all cursor-pointer shadow-sm"
          >
            <FileSpreadsheet className="w-4 h-4 text-emerald-600" />
            <span>Xuất Báo Cáo (.xlsx)</span>
          </button>

          <button
            onClick={() => setShowPrintStations(true)}
            className="px-3.5 py-2.5 rounded-xl bg-amber-50 hover:bg-amber-100 border border-amber-300 text-amber-900 font-bold text-xs flex items-center gap-1.5 transition-all cursor-pointer shadow-sm"
          >
            <Printer className="w-4 h-4 text-amber-600" />
            <span>In Thẻ Trạm</span>
          </button>

          <a
            href="/pek-science-quest.html"
            download="pek-science-quest.html"
            className="px-3.5 py-2.5 rounded-xl bg-cyan-50 hover:bg-cyan-100 border border-cyan-300 text-cyan-900 font-bold text-xs flex items-center gap-1.5 transition-all cursor-pointer shadow-sm"
            title="Tải toàn bộ web game đóng gói trong 1 file HTML duy nhất (chơi offline không cần internet)"
          >
            <Download className="w-4 h-4 text-cyan-600" />
            <span>Tải Web (.html)</span>
          </a>

          <button
            onClick={refreshAll}
            title="Làm mới trạng thái"
            className="p-2.5 rounded-xl bg-slate-100 text-slate-700 hover:text-slate-900 border border-slate-200 transition-all cursor-pointer"
          >
            <RefreshCw className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* 6 Key Stat Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3 mb-6">
        {/* Total Teams */}
        <div className="bg-white border border-slate-200 rounded-2xl p-4 shadow-sm">
          <span className="text-[11px] font-mono text-slate-500 uppercase font-bold block mb-1">
            Tổng Số Đội
          </span>
          <span className="text-2xl font-black text-slate-900 font-mono">{totalTeams}</span>
        </div>

        {/* Playing */}
        <div className="bg-white border border-slate-200 rounded-2xl p-4 shadow-sm">
          <span className="text-[11px] font-mono text-sky-600 uppercase font-bold block mb-1">
            Đang Thi Đấu
          </span>
          <span className="text-2xl font-black text-sky-700 font-mono">{playingTeams}</span>
        </div>

        {/* Completed */}
        <div className="bg-white border border-slate-200 rounded-2xl p-4 shadow-sm">
          <span className="text-[11px] font-mono text-emerald-600 uppercase font-bold block mb-1">
            Đã Hoàn Thành
          </span>
          <span className="text-2xl font-black text-emerald-700 font-mono">{completedTeams}</span>
        </div>

        {/* Current Round */}
        <div className="bg-white border border-slate-200 rounded-2xl p-4 shadow-sm">
          <span className="text-[11px] font-mono text-indigo-600 uppercase font-bold block mb-1">
            Vòng Toàn Cục
          </span>
          <span className="text-2xl font-black text-indigo-700 font-mono">
            Vòng {config.globalCurrentRound}/4
          </span>
        </div>

        {/* Highest Score */}
        <div className="bg-white border border-slate-200 rounded-2xl p-4 shadow-sm">
          <span className="text-[11px] font-mono text-amber-600 uppercase font-bold block mb-1">
            Điểm Cao Nhất
          </span>
          <span className="text-2xl font-black text-amber-700 font-mono truncate block">
            {highestScoreTeam ? `${highestScoreTeam.score} pts` : '0 pts'}
          </span>
        </div>

        {/* Best Time */}
        <div className="bg-white border border-slate-200 rounded-2xl p-4 shadow-sm">
          <span className="text-[11px] font-mono text-purple-600 uppercase font-bold block mb-1">
            Thời Gian Nhanh Nhất
          </span>
          <span className="text-2xl font-black text-purple-700 font-mono truncate block">
            {bestTimeTeam ? ScoringEngine.formatTime(bestTimeTeam.elapsedTime) : '--:--'}
          </span>
        </div>
      </div>

      {/* Navigation Sub-Tabs */}
      <div className="flex flex-wrap items-center gap-2 mb-6 border-b border-slate-200 pb-3">
        <button
          onClick={() => setAdminTab('dashboard')}
          className={`px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-2 cursor-pointer ${
            adminTab === 'dashboard'
              ? 'bg-sky-600 text-white shadow-md shadow-sky-600/20 font-black'
              : 'text-slate-600 hover:text-slate-900 bg-white border border-slate-200'
          }`}
        >
          <Layers className="w-4 h-4" />
          <span>Theo Dõi & Điều Khiển Đội Thi</span>
        </button>

        <button
          onClick={() => setAdminTab('projector')}
          className={`px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-2 cursor-pointer ${
            adminTab === 'projector'
              ? 'bg-sky-600 text-white shadow-md shadow-sky-600/20 font-black'
              : 'text-slate-600 hover:text-slate-900 bg-white border border-slate-200'
          }`}
        >
          <Tv className="w-4 h-4" />
          <span>Leaderboard Máy Chiếu Sân Khấu</span>
        </button>

        <button
          onClick={() => setAdminTab('questions')}
          className={`px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-2 cursor-pointer ${
            adminTab === 'questions'
              ? 'bg-sky-600 text-white shadow-md shadow-sky-600/20 font-black'
              : 'text-slate-600 hover:text-slate-900 bg-white border border-slate-200'
          }`}
        >
          <Database className="w-4 h-4" />
          <span>Quản Trị Ngân Hàng Câu Hỏi</span>
        </button>

        <button
          onClick={() => setAdminTab('diagnostics')}
          className={`px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-2 cursor-pointer ${
            adminTab === 'diagnostics'
              ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/20 font-black'
              : 'text-slate-600 hover:text-slate-900 bg-white border border-slate-200'
          }`}
        >
          <ShieldCheck className="w-4 h-4 text-indigo-400" />
          <span>Kiểm Tra Hệ Thống (Diagnostics)</span>
        </button>
      </div>

      {/* Tab 1: Teams Control Monitor */}
      {adminTab === 'dashboard' && (
        <TeamMonitor teams={teams} onRefresh={refreshAll} />
      )}

      {/* Tab 2: Projector Leaderboard */}
      {adminTab === 'projector' && (
        <div className="bg-white border border-slate-200 rounded-3xl p-6 shadow-xl">
          <LeaderboardView isProjectorMode={true} />
        </div>
      )}

      {/* Tab 3: Question Bank CRUD */}
      {adminTab === 'questions' && (
        <QuestionBankView onRefresh={refreshAll} />
      )}

      {/* Tab 4: System Diagnostics & Camera Test */}
      {adminTab === 'diagnostics' && (
        <SystemDiagnosticsView />
      )}

      {/* Printable QR Stations Modal */}
      {showPrintStations && (
        <StationPrintModal onClose={() => setShowPrintStations(false)} />
      )}

      {/* End Game In-App Confirmation Modal */}
      <ConfirmModal
        isOpen={showEndGameConfirm}
        title="Kết Thúc Giải Đấu PeK Science Quest"
        message="Bạn có chắc chắn muốn kết thúc toàn bộ giải đấu và công bố bảng xếp hạng chung cuộc?"
        confirmText="Xác Nhận Kết Thúc"
        type="warning"
        onConfirm={confirmEndGameAction}
        onCancel={() => setShowEndGameConfirm(false)}
      />
    </div>
  );
};
