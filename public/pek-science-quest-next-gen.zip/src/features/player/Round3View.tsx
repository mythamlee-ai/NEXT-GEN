import React, { useState, useEffect } from 'react';
import {
  Image as ImageIcon,
  HelpCircle,
  ArrowRight,
  Send,
  Lightbulb,
  CheckCircle2,
  Sparkles,
} from 'lucide-react';
import { Team, PicturePuzzle } from '../../types';
import { GameEngine } from '../../services/gameEngine';
import { ScoringEngine } from '../../services/scoringEngine';
import { Timer } from '../../components/Timer';
import { FeedbackOverlay } from '../../components/FeedbackOverlay';
import { audioManager } from '../../services/audioManager';
import { ChibiMascot } from '../../components/ChibiMascot';

interface Round3ViewProps {
  team: Team;
  onRoundComplete: () => void;
}

export const Round3View: React.FC<Round3ViewProps> = ({ team, onRoundComplete }) => {
  const [puzzles, setPuzzles] = useState<PicturePuzzle[]>([]);
  const [currentIndex, setCurrentIndex] = useState<number>(0);
  const [selectedOption, setSelectedOption] = useState<string | null>(null);
  const [textInput, setTextInput] = useState<string>('');
  const [isAnswerSubmitted, setIsAnswerSubmitted] = useState<boolean>(false);
  const [timeTaken, setTimeTaken] = useState<number>(0);

  const [feedback, setFeedback] = useState<{
    show: boolean;
    isCorrect: boolean;
    isTimeout: boolean;
    pointsEarned: number;
    explanation: string;
    correctAnswerText: string;
  } | null>(null);

  useEffect(() => {
    const list = GameEngine.getTeamRound3Puzzles(team);
    setPuzzles(list);
    const savedIdx = Math.min(team.currentQuestionIndex, list.length);
    setCurrentIndex(savedIdx);
  }, [team.id]);

  const currentPuzzle = puzzles[currentIndex];

  const normalizeStr = (str: string) => {
    return str
      .toLowerCase()
      .normalize('NFD')
      .replace(/[\u0300-\u036f]/g, '')
      .replace(/đ/g, 'd')
      .replace(/[^a-z0-9]/g, ' ')
      .replace(/\s+/g, ' ')
      .trim();
  };

  const handleSubmitAnswer = (timeout: boolean = false) => {
    if (isAnswerSubmitted || !currentPuzzle) return;
    setIsAnswerSubmitted(true);

    let isCorrect = false;
    let chosenAnswer = 'NONE';

    if (!timeout) {
      if (currentPuzzle.type === 'mcq') {
        chosenAnswer = selectedOption || 'NONE';
        isCorrect = chosenAnswer === currentPuzzle.correctAnswer;
      } else {
        chosenAnswer = textInput.trim();
        const normUser = normalizeStr(chosenAnswer);
        const normTarget = normalizeStr(currentPuzzle.correctAnswer);

        // Check exact or accepted aliases
        const aliases = (currentPuzzle.acceptedAliases || []).map(normalizeStr);
        isCorrect = normUser === normTarget || aliases.includes(normUser);
      }
    } else {
      chosenAnswer = 'TIMEOUT';
    }

    const calculatedPoints = isCorrect ? currentPuzzle.points : 0;

    GameEngine.recordAnswer(
      team,
      3,
      currentPuzzle.id,
      chosenAnswer,
      isCorrect,
      calculatedPoints,
      timeout ? currentPuzzle.timeLimit : Math.max(1, timeTaken)
    );

    const correctAnswerDisplay =
      currentPuzzle.type === 'mcq' && currentPuzzle.options
        ? `${currentPuzzle.correctAnswer}: ${currentPuzzle.options[currentPuzzle.correctAnswer as 'A' | 'B' | 'C' | 'D']}`
        : currentPuzzle.correctAnswer;

    setFeedback({
      show: true,
      isCorrect,
      isTimeout: timeout,
      pointsEarned: calculatedPoints,
      explanation: currentPuzzle.explanation,
      correctAnswerText: correctAnswerDisplay,
    });
  };

  const handleNextPuzzle = () => {
    setFeedback(null);
    setSelectedOption(null);
    setTextInput('');
    setIsAnswerSubmitted(false);
    setTimeTaken(0);

    const nextIdx = currentIndex + 1;
    if (nextIdx >= puzzles.length) {
      onRoundComplete();
    } else {
      setCurrentIndex(nextIdx);
    }
  };

  if (!currentPuzzle) {
    return (
      <div className="max-w-2xl mx-auto px-4 py-16 text-center">
        <div className="w-16 h-16 rounded-full bg-purple-100 text-purple-600 mx-auto flex items-center justify-center mb-4">
          <CheckCircle2 className="w-8 h-8" />
        </div>
        <h2 className="text-2xl font-bold text-slate-900 mb-3">Đã Hoàn Thành Vòng 3!</h2>
        <p className="text-slate-600 mb-6">Tất cả câu đố đuổi hình bắt chữ khoa học đã được giải mã.</p>
        <button
          onClick={onRoundComplete}
          className="px-8 py-3.5 rounded-xl bg-purple-600 text-white font-bold hover:bg-purple-500 transition-all cursor-pointer shadow-lg shadow-purple-600/30"
        >
          TIẾN VÀO VÒNG 4 (THE FINAL MISSION)
        </button>
      </div>
    );
  }

  return (
    <div className="max-w-3xl mx-auto px-4 py-6 sm:py-8">
      {/* Round Header & Live Status */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6">
        <div className="flex items-center gap-3">
          <ChibiMascot
            expression="thinking"
            size="sm"
            showSpeechBubble={false}
          />
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className="text-xs font-mono font-bold text-purple-700 uppercase tracking-widest">
                VÒNG 3: PICTURE PUZZLE (ĐUỔI HÌNH BẮT CHỮ)
              </span>
            </div>
            <h2 className="text-lg sm:text-xl font-black text-slate-900">
              Câu Đố {currentIndex + 1} / {puzzles.length}
            </h2>
          </div>
        </div>

        {/* Real Countdown Timer */}
        <Timer
          key={currentPuzzle.id}
          timeLimit={currentPuzzle.timeLimit}
          onTimeout={() => handleSubmitAnswer(true)}
          isPaused={isAnswerSubmitted}
          onTick={(_timeLeft, taken) => setTimeTaken(taken)}
        />
      </div>

      {/* Progress Dots */}
      <div className="flex items-center gap-1.5 mb-6">
        {puzzles.map((p, idx) => {
          const isDone = idx < currentIndex;
          const isCurrent = idx === currentIndex;
          return (
            <div
              key={p.id}
              className={`h-2.5 flex-1 rounded-full transition-all duration-300 ${
                isCurrent
                  ? 'bg-purple-500 shadow-md shadow-purple-500/50 scale-y-125'
                  : isDone
                  ? 'bg-emerald-500'
                  : 'bg-slate-200'
              }`}
            />
          );
        })}
      </div>

      {/* Puzzle Card - Bright & Crisp */}
      <div className="bg-white border border-slate-200/90 rounded-3xl p-6 sm:p-8 backdrop-blur-xl shadow-xl shadow-slate-100 mb-6 relative overflow-hidden">
        {/* Header Badges */}
        <div className="flex items-center justify-between gap-3 mb-6">
          <div className="flex items-center gap-2">
            <span className="px-3 py-1 rounded-full text-xs font-bold bg-purple-100 text-purple-800 border border-purple-300">
              {currentPuzzle.topic}
            </span>
            <span className="text-xs font-mono text-slate-500">
              {currentPuzzle.type === 'mcq' ? 'Trắc nghiệm 4 đáp án' : 'Nhập tự do'}
            </span>
          </div>

          <span className="font-mono font-bold text-amber-700 bg-amber-100 px-2.5 py-1 rounded border border-amber-300 text-sm">
            +{currentPuzzle.points} pts
          </span>
        </div>

        {/* Big Puzzle Picture */}
        <div className="relative rounded-2xl overflow-hidden border-2 border-purple-200 shadow-md bg-slate-50 mb-6">
          <img
            src={currentPuzzle.image}
            alt={currentPuzzle.question}
            className="w-full h-56 sm:h-72 object-contain bg-white p-2"
          />
        </div>

        {/* Puzzle Prompt Question */}
        <div className="mb-6">
          <div className="flex items-center gap-2 text-xs font-mono font-bold text-purple-700 uppercase mb-1">
            <Lightbulb className="w-4 h-4 text-purple-600" />
            <span>CÂU HỎI THÁM MÃ:</span>
          </div>
          <h3 className="text-base sm:text-lg font-bold text-slate-900 leading-snug">
            {currentPuzzle.question}
          </h3>
        </div>

        {/* Answer Section */}
        {currentPuzzle.type === 'mcq' && currentPuzzle.options ? (
          /* MCQ Options */
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 mb-6">
            {(['A', 'B', 'C', 'D'] as const).map((key) => {
              const isSelected = selectedOption === key;
              const optionText = currentPuzzle.options?.[key] || '';
              return (
                <button
                  key={key}
                  onClick={() => {
                    if (isAnswerSubmitted) return;
                    audioManager.playButtonTap();
                    setSelectedOption(key);
                  }}
                  disabled={isAnswerSubmitted}
                  className={`p-3.5 rounded-2xl border text-left transition-all duration-150 flex items-start gap-3 cursor-pointer ${
                    isSelected
                      ? 'bg-purple-50 border-2 border-purple-500 text-purple-950 shadow-md shadow-purple-100 font-bold scale-[1.01]'
                      : 'bg-slate-50 hover:bg-slate-100 border-slate-200 text-slate-800'
                  }`}
                >
                  <span
                    className={`w-6 h-6 rounded-lg flex items-center justify-center font-mono font-bold text-xs flex-shrink-0 ${
                      isSelected
                        ? 'bg-purple-600 text-white'
                        : 'bg-white text-slate-600 border border-slate-200'
                    }`}
                  >
                    {key}
                  </span>
                  <span className="text-xs sm:text-sm font-semibold pt-0.5">{optionText}</span>
                </button>
              );
            })}
          </div>
        ) : (
          /* Text Input */
          <div className="mb-6">
            <div className="relative">
              <input
                type="text"
                value={textInput}
                onChange={(e) => setTextInput(e.target.value)}
                disabled={isAnswerSubmitted}
                placeholder="Nhập câu trả lời hoặc thuật ngữ khoa học..."
                className="w-full bg-slate-50 border border-slate-300 focus:border-purple-500 focus:bg-white focus:ring-2 focus:ring-purple-200 rounded-2xl pl-4 pr-12 py-4 text-slate-900 placeholder-slate-400 outline-none text-sm transition-all font-semibold"
              />
              <Send className="w-5 h-5 text-purple-500 absolute right-4 top-4 pointer-events-none" />
            </div>
            <p className="text-[11px] text-slate-500 mt-2 font-mono">
              * Tự động chấp nhận từ đồng nghĩa, tiếng Việt có dấu hoặc không dấu
            </p>
          </div>
        )}

        {/* Bottom Actions */}
        <div className="flex items-center justify-between pt-4 border-t border-slate-100">
          <p className="text-xs text-slate-500 font-mono">
            {currentPuzzle.type === 'mcq'
              ? selectedOption
                ? `Đã chọn: [${selectedOption}]`
                : 'Chọn 1 đáp án'
              : textInput.trim()
              ? `Đã nhập: "${textInput}"`
              : 'Nhập câu trả lời'}
          </p>

          <button
            onClick={() => handleSubmitAnswer(false)}
            disabled={
              isAnswerSubmitted ||
              (currentPuzzle.type === 'mcq' ? !selectedOption : !textInput.trim())
            }
            className="px-7 py-3 rounded-xl bg-gradient-to-r from-purple-500 to-indigo-600 hover:from-purple-400 hover:to-indigo-500 text-white font-bold text-sm shadow-md shadow-purple-500/25 transition-all disabled:opacity-40 disabled:cursor-not-allowed flex items-center gap-2 cursor-pointer"
          >
            <span>XÁC NHẬN GIẢI MÃ</span>
            <ArrowRight className="w-4 h-4 stroke-[2.5]" />
          </button>
        </div>
      </div>

      {/* Answer Feedback Popup */}
      {feedback && feedback.show && (
        <FeedbackOverlay
          isCorrect={feedback.isCorrect}
          isTimeout={feedback.isTimeout}
          pointsEarned={feedback.pointsEarned}
          explanation={feedback.explanation}
          correctAnswerText={feedback.correctAnswerText}
          onNext={handleNextPuzzle}
        />
      )}
    </div>
  );
};
