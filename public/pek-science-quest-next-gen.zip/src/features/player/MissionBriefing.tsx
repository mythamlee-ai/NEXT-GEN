import React from 'react';
import {
  Compass,
  Zap,
  HelpCircle,
  Image as ImageIcon,
  QrCode,
  ArrowRight,
  ShieldCheck,
  Award,
  Sparkles,
  Clock,
  UserCheck,
  Map as MapIcon,
  Key,
  Gem,
} from 'lucide-react';
import { Team } from '../../types';
import { audioManager } from '../../services/audioManager';
import { ChibiMascot } from '../../components/ChibiMascot';

interface MissionBriefingProps {
  team: Team;
  onStartRound1: () => void;
}

export const MissionBriefing: React.FC<MissionBriefingProps> = ({ team, onStartRound1 }) => {
  const handleStart = () => {
    audioManager.playChestOpen();
    onStartRound1();
  };

  return (
    <div className="max-w-5xl mx-auto px-4 py-6 sm:py-10">
      {/* Top Banner - Bright & Adventurous */}
      <div className="bg-white border-2 border-amber-300 rounded-3xl p-6 sm:p-8 shadow-xl mb-8 relative overflow-hidden">
        {/* Concept Visual Banner Artwork */}
        <div className="mb-6 rounded-2xl overflow-hidden border border-amber-200 shadow-md relative h-40 sm:h-52 w-full">
          <img
            src="/src/assets/images/science_banner_1791188435725.jpg"
            alt="Pétrus Ký Science Quest Concept"
            className="w-full h-full object-cover object-center"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-slate-950/80 via-slate-950/20 to-transparent flex flex-col justify-end p-4 sm:p-6 text-white">
            <span className="text-xs font-mono font-bold tracking-wider text-amber-300 uppercase">
              TỔ KHOA HỌC TỰ NHIÊN • TRƯỜNG PÉTRUS KÝ
            </span>
            <h2 className="text-xl sm:text-2xl font-black tracking-tight drop-shadow-md">
              PÉTRUS KÝ SCIENCE QUEST • THE FINAL CODE
            </h2>
            <p className="text-xs text-slate-200 font-medium">
              Khám Phá – Tư Duy – Chinh Phục Rương Kho Báu
            </p>
          </div>
        </div>

        <div className="absolute top-0 right-0 w-80 h-80 bg-amber-100/60 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute bottom-0 left-0 w-80 h-80 bg-sky-100/50 rounded-full blur-3xl pointer-events-none" />

        <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 relative z-10">
          <div className="flex items-center gap-4">
            <ChibiMascot
              expression="waving"
              size="lg"
              showSpeechBubble={true}
              speechText={`Xin chào Đội ${team.teamName}! Tấm bản đồ cổ đã mở ra, chúng ta bắt đầu săn tìm kho báu thôi!`}
              accessory="map"
            />
            <div>
              <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-100 border border-amber-300 text-amber-900 text-xs font-mono font-bold tracking-wider mb-2">
                <Compass className="w-4 h-4 text-amber-600 animate-spin" style={{ animationDuration: '8s' }} />
                <span>HÀNH TRÌNH TRUY TÌM KHO BÁU KHOA HỌC PÉTRUS KÝ</span>
              </div>
              <h1 className="text-2xl sm:text-3xl font-black text-slate-900 tracking-tight">
                ĐỘI: {team.teamName.toUpperCase()}
              </h1>
              <div className="text-slate-600 text-xs sm:text-sm flex flex-wrap items-center gap-2 mt-1">
                <span className="font-semibold text-slate-700 bg-slate-100 px-2.5 py-1 rounded-lg border border-slate-200">
                  Lớp: {team.className}
                </span>
                <span className="font-mono text-amber-800 bg-amber-50 px-2.5 py-1 rounded-lg border border-amber-200 font-bold">
                  MÃ ĐỘI: {team.teamCode}
                </span>
              </div>
              {team.captainName && (
                <div className="flex items-center gap-1.5 mt-2 text-xs font-semibold text-indigo-700">
                  <UserCheck className="w-4 h-4 text-indigo-500" />
                  <span>Đội Trưởng: <strong className="text-indigo-900 font-bold">{team.captainName}</strong></span>
                </div>
              )}
            </div>
          </div>

          <div className="flex flex-col sm:flex-row items-center gap-3">
            <button
              onClick={handleStart}
              className="w-full sm:w-auto px-8 py-4 rounded-2xl bg-gradient-to-r from-amber-500 via-yellow-500 to-amber-600 hover:from-amber-400 hover:to-yellow-400 text-slate-950 font-black text-base flex items-center justify-center gap-2 shadow-lg shadow-amber-500/25 transition-all transform hover:scale-102 active:scale-98 cursor-pointer"
            >
              <span>TIẾP TỤC HÀNH TRÌNH</span>
              <ArrowRight className="w-5 h-5 stroke-[2.5]" />
            </button>
          </div>
        </div>
      </div>

      {/* Narrative Story Box */}
      <div className="bg-amber-50/80 border-2 border-amber-200 rounded-3xl p-6 sm:p-7 shadow-sm mb-8 text-center relative overflow-hidden">
        <span className="text-xs font-mono font-bold uppercase tracking-widest text-amber-800 bg-amber-100 px-3 py-1 rounded-full border border-amber-300 inline-block mb-3">
          📜 CỐT TRUYỆN HUYỀN THOẠI PÉTRUS KÝ SCIENCE QUEST
        </span>
        <p className="text-slate-800 text-sm sm:text-base leading-relaxed max-w-3xl mx-auto font-medium">
          “Kho báu khoa học huyền thoại của Pétrus Ký đã được bảo vệ qua nhiều thế hệ. Muốn mở được <strong>RƯƠNG KHO BÁU CUỐI CÙNG</strong>, đội chơi phải dũng cảm vượt qua <strong>4 vùng thử thách kỳ thú</strong>. Mỗi vòng hoàn thành sẽ thu thập một phần thưởng quý giá. Khi hoàn tất cả 4 vòng, đội chơi sẽ bước vào bẻ khóa Rương Báu May Mắn!”
        </p>
      </div>

      {/* 4 Lands on the Treasure Archipelago */}
      <div className="mb-8">
        <h2 className="text-xl sm:text-2xl font-black text-slate-900 mb-4 flex items-center gap-2">
          <Sparkles className="w-5 h-5 text-amber-500" />
          <span>4 VÙNG ĐẤT TRÊN BẢN ĐỒ KHO BÁU PEK</span>
        </h2>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {/* Land 1 */}
          <div className="bg-white border-2 border-slate-200 rounded-2xl p-5 hover:border-amber-400 transition-all relative overflow-hidden group shadow-sm hover:shadow-md">
            <div className="flex items-start gap-4">
              <div className="w-14 h-14 rounded-2xl bg-sky-100 text-sky-600 flex items-center justify-center border border-sky-200 flex-shrink-0 group-hover:scale-105 transition-transform text-2xl">
                🏝️
              </div>
              <div className="flex-1">
                <div className="flex items-center justify-between mb-1">
                  <span className="text-xs font-mono font-bold text-sky-600 uppercase tracking-wider">
                    VÒNG 1 • ĐẢO KHOA HỌC
                  </span>
                  <span className="text-[11px] font-mono text-slate-500 flex items-center gap-1">
                    <Clock className="w-3 h-3" /> 45s/câu
                  </span>
                </div>
                <h3 className="text-base font-bold text-slate-900 mb-1">THE SCIENCE ISLAND</h3>
                <p className="text-xs text-slate-600 leading-relaxed mb-2">
                  Vượt qua 9 câu hỏi liên môn Lý – Hóa – Sinh tốc độ cao để bẻ gãy lăng kính phong ấn đầu tiên.
                </p>
                <div className="inline-flex items-center gap-1 text-[11px] font-mono text-sky-700 bg-sky-50 px-2 py-0.5 rounded border border-sky-200">
                  <Key className="w-3 h-3" />
                  <span>Vật phẩm: <strong>Chìa Khóa Quang Phổ Alpha</strong></span>
                </div>
              </div>
            </div>
          </div>

          {/* Land 2 */}
          <div className="bg-white border-2 border-slate-200 rounded-2xl p-5 hover:border-amber-400 transition-all relative overflow-hidden group shadow-sm hover:shadow-md">
            <div className="flex items-start gap-4">
              <div className="w-14 h-14 rounded-2xl bg-indigo-100 text-indigo-600 flex items-center justify-center border border-indigo-200 flex-shrink-0 group-hover:scale-105 transition-transform text-2xl">
                🏰
              </div>
              <div className="flex-1">
                <div className="flex items-center justify-between mb-1">
                  <span className="text-xs font-mono font-bold text-indigo-600 uppercase tracking-wider">
                    VÒNG 2 • VÙNG ĐẤT BÍ ẨN
                  </span>
                  <span className="text-[11px] font-mono text-slate-500 flex items-center gap-1">
                    <Clock className="w-3 h-3" /> 60s/thầy cô
                  </span>
                </div>
                <h3 className="text-base font-bold text-slate-900 mb-1">THE MYSTERY TEACHER</h3>
                <p className="text-xs text-slate-600 leading-relaxed mb-2">
                  Lật mở các gợi ý dữ liệu để nhận diện chân dung các bậc thầy Khoa học Tự nhiên Trường Pétrus Ký.
                </p>
                <div className="inline-flex items-center gap-1 text-[11px] font-mono text-indigo-700 bg-indigo-50 px-2 py-0.5 rounded border border-indigo-200">
                  <MapIcon className="w-3 h-3" />
                  <span>Vật phẩm: <strong>Mảnh Bản Đồ Cổ Pétrus Ký</strong></span>
                </div>
              </div>
            </div>
          </div>

          {/* Land 3 */}
          <div className="bg-white border-2 border-slate-200 rounded-2xl p-5 hover:border-amber-400 transition-all relative overflow-hidden group shadow-sm hover:shadow-md">
            <div className="flex items-start gap-4">
              <div className="w-14 h-14 rounded-2xl bg-purple-100 text-purple-600 flex items-center justify-center border border-purple-200 flex-shrink-0 group-hover:scale-105 transition-transform text-2xl">
                🪨
              </div>
              <div className="flex-1">
                <div className="flex items-center justify-between mb-1">
                  <span className="text-xs font-mono font-bold text-purple-600 uppercase tracking-wider">
                    VÒNG 3 • HANG ĐỘNG HÌNH ẢNH
                  </span>
                  <span className="text-[11px] font-mono text-slate-500 flex items-center gap-1">
                    <Clock className="w-3 h-3" /> 60s/câu đố
                  </span>
                </div>
                <h3 className="text-base font-bold text-slate-900 mb-1">THE PICTURE CAVE</h3>
                <p className="text-xs text-slate-600 leading-relaxed mb-2">
                  Đuổi hình bắt chữ rebus khoa học thị giác để giải phóng Viên Thạch Anh năng lượng soi đường.
                </p>
                <div className="inline-flex items-center gap-1 text-[11px] font-mono text-purple-700 bg-purple-50 px-2 py-0.5 rounded border border-purple-200">
                  <Gem className="w-3 h-3" />
                  <span>Vật phẩm: <strong>Đá Quý Thạch Anh Thám Mã</strong></span>
                </div>
              </div>
            </div>
          </div>

          {/* Land 4 */}
          <div className="bg-white border-2 border-slate-200 rounded-2xl p-5 hover:border-amber-400 transition-all relative overflow-hidden group shadow-sm hover:shadow-md">
            <div className="flex items-start gap-4">
              <div className="w-14 h-14 rounded-2xl bg-amber-100 text-amber-600 flex items-center justify-center border border-amber-200 flex-shrink-0 group-hover:scale-105 transition-transform text-2xl">
                💎
              </div>
              <div className="flex-1">
                <div className="flex items-center justify-between mb-1">
                  <span className="text-xs font-mono font-bold text-amber-700 uppercase tracking-wider">
                    VÒNG 4 • KHO BÁU CUỐI CÙNG
                  </span>
                  <span className="text-[11px] font-mono text-slate-500 flex items-center gap-1">
                    <Clock className="w-3 h-3" /> 180s
                  </span>
                </div>
                <h3 className="text-base font-bold text-slate-900 mb-1">THE FINAL TREASURE</h3>
                <p className="text-xs text-slate-600 leading-relaxed mb-2">
                  Quét mã QR trạm thực địa và chụp hình hiện vật khoa học để kích hoạt bung mở Rương Kho Báu!
                </p>
                <div className="inline-flex items-center gap-1 text-[11px] font-mono text-amber-800 bg-amber-50 px-2 py-0.5 rounded border border-amber-200">
                  <Compass className="w-3 h-3" />
                  <span>Bảo vật: <strong>La Bàn Vàng Tối Thượng Next Gen</strong></span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
