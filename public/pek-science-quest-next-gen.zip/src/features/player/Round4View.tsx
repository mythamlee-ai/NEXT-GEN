import React, { useState, useEffect, useMemo } from 'react';
import confetti from 'canvas-confetti';
import {
  KeyRound,
  Sparkles,
  ArrowRight,
  ShieldCheck,
  AlertCircle,
  HelpCircle,
  CheckCircle2,
  RotateCcw,
  Compass,
  Award,
  Zap,
  Dice5,
  Lock,
  Unlock,
  Check,
  Lightbulb,
  FileText,
} from 'lucide-react';
import { Team, MysteryBoxEffect, MysteryTreasureCode } from '../../types';
import { GameEngine } from '../../services/gameEngine';
import { storageService } from '../../services/storageService';
import { audioManager } from '../../services/audioManager';
import { ChibiMascot } from '../../components/ChibiMascot';

interface Round4ViewProps {
  team: Team;
  onFinishGame: () => void;
}

interface MysteryChestOption {
  id: number;
  name: string;
  icon: string;
  color: string;
  border: string;
  codeSuggestion: string;
}

export const Round4View: React.FC<Round4ViewProps> = ({ team, onFinishGame }) => {
  const [enteredCode, setEnteredCode] = useState<string>('');
  const [isOpeningBox, setIsOpeningBox] = useState<boolean>(false);
  const [boxOpened, setBoxOpened] = useState<boolean>(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [showHintList, setShowHintList] = useState<boolean>(false);

  // Danh sách mật mã đang kích hoạt trong ngân hàng
  const [bankCodes, setBankCodes] = useState<MysteryTreasureCode[]>(() =>
    storageService.getMysteryCodes().filter((c) => c.active)
  );

  // Result state
  const [mysteryResult, setMysteryResult] = useState<{
    effect: MysteryBoxEffect;
    pointsDelta: number;
    baseScore: number;
    newTotalScore: number;
    codeName: string;
    description: string;
    solutionAnswer: string;
  } | null>(null);

  // Mascot statement
  const [mascotDialogue, setMascotDialogue] = useState<string>(
    'Chào mừng các nhà thám hiểm đến VÒNG 4: KHO BÁU CUỐI CÙNG! Hãy nhập mật mã giải mật thư từ trạm thực địa để mở khóa đáp án và nhận điểm thưởng may mắn!'
  );
  const [mascotExp, setMascotExp] = useState<
    'idle' | 'waving' | 'pointing' | 'thinking' | 'surprised' | 'celebrating' | 'excited' | 'warning'
  >('excited');

  // Điểm tích lũy 3 vòng trước
  const baseScore =
    (team.roundScores[1] || 0) + (team.roundScores[2] || 0) + (team.roundScores[3] || 0);

  // 6 Rương kho báu đại diện cho các trạm
  const chestsList: MysteryChestOption[] = useMemo(
    () => [
      { id: 1, name: 'Rương Hoàng Kim', icon: '👑', color: 'from-amber-400 via-yellow-500 to-amber-600', border: 'border-yellow-300', codeSuggestion: 'LUCKY-GOLD' },
      { id: 2, name: 'Rương Kim Cương', icon: '💎', color: 'from-cyan-400 via-sky-500 to-blue-600', border: 'border-cyan-300', codeSuggestion: 'DIAMOND-PEK' },
      { id: 3, name: 'Rương Lõi Lượng Tử', icon: '⚡', color: 'from-purple-400 via-indigo-500 to-violet-600', border: 'border-purple-300', codeSuggestion: 'PEK-QUANTUM-2026' },
      { id: 4, name: 'Rương Hồng Ngọc', icon: '🌟', color: 'from-rose-400 via-pink-500 to-red-600', border: 'border-rose-300', codeSuggestion: 'RUBY-QUEST' },
      { id: 5, name: 'Rương Di Truyền PeK', icon: '🧬', color: 'from-emerald-400 via-teal-500 to-cyan-600', border: 'border-emerald-300', codeSuggestion: 'PEK-GENOME-ALPHA' },
      { id: 6, name: 'Rương Next Gen Champion', icon: '🏆', color: 'from-amber-500 via-orange-500 to-yellow-600', border: 'border-amber-300', codeSuggestion: 'NEXTGEN-CHAMPION' },
    ],
    []
  );

  // Kiểm tra xem đội đã từng mở mật mã vòng 4 chưa
  useEffect(() => {
    if (team.round4MysteryCode && team.round4MysteryEffect) {
      setEnteredCode(team.round4MysteryCode);
      const pointsDelta = team.roundScores[4] || 0;
      const matched = storageService.getMysteryCodeByCode(team.round4MysteryCode);

      setMysteryResult({
        effect: team.round4MysteryEffect,
        pointsDelta,
        baseScore: team.round4BaseScore ?? Math.max(0, team.score - pointsDelta),
        newTotalScore: team.score,
        codeName: matched?.name || `Mật Mã [${team.round4MysteryCode}]`,
        description: matched?.description || 'Điểm thưởng may mắn Vòng 4 đã được ghi nhận vào tổng điểm.',
        solutionAnswer: matched?.solutionAnswer || 'Đã giải mã thành công phong ấn kho báu!',
      });
      setBoxOpened(true);
    }
  }, [team.id]);

  // Xử lý khi học sinh nhập mật mã
  const handleProcessCode = (codeToOpen: string, customChestName?: string) => {
    const clean = codeToOpen.trim().toUpperCase();
    if (!clean) {
      setErrorMsg('Vui lòng nhập mật mã từ Ban Giám khảo hoặc Thẻ trạm thực địa!');
      audioManager.playIncorrect();
      return;
    }

    setIsOpeningBox(true);
    setErrorMsg(null);
    audioManager.playPop();

    setMascotDialogue(`Đang xác thực mật mã [${clean}]... Phong ấn kho báu đang rung chuyển dữ dội!`);
    setMascotExp('surprised');

    setTimeout(() => {
      // Roll random reward strictly among: (+5, +10, -5, -10, *2, :2)
      const randomReward = GameEngine.getRandomRound4Effect();
      const res = GameEngine.applyRound4MysteryBox(
        team,
        clean,
        randomReward.effect,
        customChestName,
        randomReward.description
      );

      setMysteryResult(res);
      setIsOpeningBox(false);
      setBoxOpened(true);

      // Audio & Confetti
      if (res.effect === '*2' || res.pointsDelta > 0) {
        audioManager.playVictory();
        try {
          confetti({
            particleCount: 110,
            spread: 80,
            origin: { y: 0.6 },
            colors: ['#f59e0b', '#3b82f6', '#10b981', '#8b5cf6'],
          });
        } catch {}

        if (res.effect === '*2') {
          setMascotDialogue('🎉 SIÊU VẬN MAY ĐỈNH CAO! Mở trúng Nhân Đôi Toàn Bộ Điểm Số (*2) của 3 vòng trước!');
          setMascotExp('celebrating');
        } else {
          setMascotDialogue(`✨ XUẤT SẮC! Đội của bạn nhận được ${res.effect} ĐIỂM vào quỹ điểm tổng!`);
          setMascotExp('celebrating');
        }
      } else {
        audioManager.playWarning();
        if (res.effect === ':2') {
          setMascotDialogue('Ôi không! Hố Đen Hư Không đã chia đôi điểm số (:2)! Nhưng tinh thần chiến binh Pétrus Ký không bao giờ lùi bước!');
          setMascotExp('warning');
        } else {
          setMascotDialogue(`Một chút cạm bẫy hải tặc (${res.effect} điểm), nhưng các bạn đã hoàn thành xuất sắc toàn bộ 4 vòng!`);
          setMascotExp('thinking');
        }
      }
    }, 2000);
  };

  const handleFormSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    handleProcessCode(enteredCode);
  };

  return (
    <div className="max-w-4xl mx-auto px-4 py-6 sm:py-8">
      {/* Header Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6">
        <div className="flex items-center gap-3">
          <ChibiMascot expression={mascotExp} size="sm" showSpeechBubble={false} accessory="compass" />
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className="text-xs font-mono font-bold text-amber-800 bg-amber-100 px-2.5 py-0.5 rounded-full uppercase tracking-wider border border-amber-300">
                VÒNG 4: THE FINAL TREASURE
              </span>
              <span className="text-xs font-mono text-purple-700 bg-purple-50 px-2 py-0.5 rounded-md font-bold">
                🎁 MẬT MÃ TRẠM & ĐIỂM RANDOM
              </span>
            </div>
            <h2 className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight">
              Bẻ Khóa Mật Mã & Rương Kho Báu PeK
            </h2>
          </div>
        </div>

        {/* Live Score Tickers */}
        <div className="flex items-center gap-2">
          <div className="bg-emerald-50 border border-emerald-300 text-emerald-800 px-3 py-1.5 rounded-xl text-xs font-mono font-bold flex items-center gap-1.5 shadow-xs">
            <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
            <span>MÁY #{team.teamCode}</span>
          </div>

          <div className="bg-white border border-slate-200 rounded-xl px-3 py-1.5 shadow-xs flex items-center gap-2">
            <span className="text-xs font-mono text-slate-500 font-bold uppercase">Điểm 3 Vòng:</span>
            <span className="text-lg font-black text-indigo-700 font-mono">{baseScore} pts</span>
          </div>
        </div>
      </div>

      {/* Mascot Narrative Card */}
      <div className="mb-6 p-4 rounded-3xl bg-amber-50/90 border-2 border-amber-300/80 shadow-sm flex items-center gap-3.5">
        <div className="w-10 h-10 rounded-2xl bg-amber-200/80 flex items-center justify-center text-xl flex-shrink-0">
          🧭
        </div>
        <p className="text-xs sm:text-sm text-amber-950 font-bold leading-relaxed">
          <strong className="text-amber-800 uppercase tracking-wide">PÉTRUS KÝ GUIDE:</strong> {mascotDialogue}
        </p>
      </div>

      {/* STAGE 1: BEFORE BOX OPENED OR WHILE PROCESSING */}
      {!boxOpened && (
        <div className="bg-white border-2 border-slate-200 rounded-3xl p-6 sm:p-10 shadow-xl shadow-slate-100 mb-6 relative overflow-hidden">
          {/* Opening Animation State */}
          {isOpeningBox ? (
            <div className="py-12 space-y-6 text-center">
              <div className="w-36 h-36 sm:w-44 sm:h-44 mx-auto rounded-3xl bg-gradient-to-br from-amber-400 via-yellow-500 to-amber-600 border-4 border-yellow-200 shadow-2xl shadow-amber-500/30 flex items-center justify-center animate-bounce scale-110">
                <div className="text-6xl sm:text-7xl filter drop-shadow-md">⚡</div>
              </div>
              <div className="flex items-center justify-center gap-2 text-amber-700 font-black text-base animate-pulse font-mono tracking-wider">
                <Sparkles className="w-6 h-6 animate-spin text-amber-500" />
                <span>ĐANG GIẢI MÃ PHONG ẤN & QUAY ĐIỂM THƯỞNG...</span>
                <Sparkles className="w-6 h-6 animate-spin text-amber-500" />
              </div>
              <p className="text-xs text-slate-500 font-mono">
                Số điểm thưởng đang được phân bổ ngẫu nhiên (+5, +10, -5, -10, *2, :2)...
              </p>
            </div>
          ) : (
            <div className="max-w-2xl mx-auto space-y-8">
              {/* PRIMARY ACTION: INPUT MẬT MÃ */}
              <div className="p-6 sm:p-8 rounded-3xl bg-gradient-to-br from-slate-900 via-indigo-950 to-slate-900 text-white shadow-xl border-2 border-amber-400/40 text-center relative overflow-hidden">
                <div className="absolute top-0 right-0 w-48 h-48 bg-amber-400/10 rounded-full blur-2xl pointer-events-none" />

                <div className="relative z-10 space-y-4">
                  <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-400/20 text-amber-300 font-mono font-bold text-xs border border-amber-400/30 uppercase">
                    <KeyRound className="w-3.5 h-3.5" />
                    <span>NHẬP MẬT MÃ / TỪ KHÓA TRẠM THỰC ĐỊA</span>
                  </div>

                  <h3 className="text-xl sm:text-2xl font-black text-white">
                    Bẻ Khóa Mật Mã Trạm Cuối Cùng
                  </h3>

                  <p className="text-xs text-slate-300 max-w-lg mx-auto leading-relaxed">
                    Nhập mật mã nhận được từ Ban Giám khảo hoặc Thẻ trạm. Hệ thống sẽ công bố đáp án giải mã khoa học và kích hoạt vòng quay điểm thưởng ngẫu nhiên (+5, +10, -5, -10, *2, :2)!
                  </p>

                  <form onSubmit={handleFormSubmit} className="max-w-md mx-auto pt-2 space-y-3">
                    <div className="relative">
                      <input
                        type="text"
                        value={enteredCode}
                        onChange={(e) => setEnteredCode(e.target.value.toUpperCase())}
                        placeholder="Nhập mã (VD: PEK-QUANTUM-2026, LUCKY-GOLD...)"
                        autoFocus
                        className="w-full px-5 py-3.5 rounded-2xl bg-white text-slate-900 font-mono font-black text-base sm:text-lg tracking-wider uppercase border-2 border-amber-400 shadow-inner focus:outline-none focus:ring-4 focus:ring-amber-400/30 text-center placeholder:text-slate-400 placeholder:font-normal placeholder:text-sm"
                      />
                    </div>

                    <button
                      type="submit"
                      disabled={!enteredCode.trim()}
                      className="w-full py-3.5 rounded-2xl bg-gradient-to-r from-amber-400 via-yellow-400 to-amber-500 hover:from-amber-300 hover:to-yellow-300 disabled:opacity-50 text-slate-950 font-black text-sm uppercase tracking-wider shadow-lg shadow-amber-400/25 flex items-center justify-center gap-2 transition-all cursor-pointer transform hover:scale-101 active:scale-98"
                    >
                      <Zap className="w-4 h-4 fill-current" />
                      <span>XÁC NHẬN MẬT MÃ & BẺ KHÓA NGAY</span>
                    </button>
                  </form>

                  {errorMsg && (
                    <div className="p-3 rounded-xl bg-rose-500/20 border border-rose-400/40 text-xs text-rose-200 font-bold flex items-center justify-center gap-2">
                      <AlertCircle className="w-4 h-4 text-rose-400 flex-shrink-0" />
                      <span>{errorMsg}</span>
                    </div>
                  )}

                  {/* Toggle view active codes */}
                  <div className="pt-2">
                    <button
                      type="button"
                      onClick={() => setShowHintList(!showHintList)}
                      className="text-xs text-amber-300 hover:text-amber-200 font-mono underline cursor-pointer flex items-center justify-center gap-1 mx-auto"
                    >
                      <Lightbulb className="w-3.5 h-3.5 text-amber-400" />
                      <span>{showHintList ? 'Ẩn danh sách mã mẫu' : 'Xem danh sách các trạm thực địa mẫu'}</span>
                    </button>
                  </div>

                  {showHintList && (
                    <div className="pt-2 grid grid-cols-2 sm:grid-cols-3 gap-2 text-left">
                      {bankCodes.slice(0, 6).map((c) => (
                        <button
                          key={c.id}
                          type="button"
                          onClick={() => {
                            setEnteredCode(c.code);
                            setErrorMsg(null);
                          }}
                          className="p-2 rounded-xl bg-white/10 hover:bg-white/20 border border-white/20 text-left transition-all cursor-pointer"
                        >
                          <span className="font-mono font-bold text-amber-300 text-xs block truncate">
                            {c.code}
                          </span>
                          <span className="text-[10px] text-slate-300 block truncate">{c.name}</span>
                        </button>
                      ))}
                    </div>
                  )}
                </div>
              </div>

              {/* SECONDARY OPTION: CHỌN RƯƠNG TRỰC TIẾP */}
              <div className="pt-4 border-t border-slate-200 text-center">
                <span className="text-xs font-mono font-bold text-slate-600 uppercase tracking-wider block mb-2">
                  HOẶC CHỌN TRỰC TIẾP 1 TRONG 6 RƯƠNG KHO BÁU BÊN DƯỚI
                </span>
                <p className="text-xs text-slate-500 mb-4">
                  Mỗi rương gắn với một từ khóa khoa học trạm thực địa PeK:
                </p>

                <div className="grid grid-cols-2 sm:grid-cols-3 gap-3.5 sm:gap-4">
                  {chestsList.map((chest) => (
                    <button
                      key={chest.id}
                      type="button"
                      onClick={() => handleProcessCode(chest.codeSuggestion, chest.name)}
                      className={`p-4 rounded-2xl bg-gradient-to-br ${chest.color} border-2 ${chest.border} text-white shadow-lg hover:shadow-2xl hover:scale-105 active:scale-95 transition-all cursor-pointer flex flex-col items-center justify-center group relative overflow-hidden`}
                    >
                      <div className="absolute top-1 right-2 text-[10px] font-mono font-bold opacity-60">
                        #{chest.id}
                      </div>
                      <div className="text-4xl sm:text-5xl my-2 transform group-hover:scale-110 transition-transform filter drop-shadow-md">
                        {chest.icon}
                      </div>
                      <span className="font-black text-xs sm:text-sm tracking-wide text-slate-950 bg-white/90 px-2.5 py-1 rounded-xl shadow-xs mt-1">
                        {chest.name}
                      </span>
                      <span className="text-[10px] font-mono text-white/90 mt-1 font-bold">
                        [{chest.codeSuggestion}]
                      </span>
                    </button>
                  ))}
                </div>
              </div>
            </div>
          )}
        </div>
      )}

      {/* STAGE 2: AFTER CODE UNLOCKED (REVEAL ANSWER & RANDOM LUCK SCORE) */}
      {boxOpened && mysteryResult && (
        <div className="bg-white border-2 border-slate-200 rounded-3xl p-6 sm:p-10 shadow-xl shadow-slate-100 mb-6 text-center max-w-2xl mx-auto space-y-6 animate-in zoom-in-95 duration-500">
          <div className="w-20 h-20 sm:w-24 sm:h-24 mx-auto rounded-3xl bg-amber-100 text-amber-700 flex items-center justify-center text-4xl sm:text-5xl shadow-lg shadow-amber-100">
            💎
          </div>

          <div>
            <span className="text-xs font-mono font-bold text-amber-800 bg-amber-100 px-3 py-1 rounded-full uppercase">
              BẺ KHÓA THÀNH CÔNG VÒNG 4
            </span>
            <h3 className="text-2xl sm:text-3xl font-black text-slate-900 mt-2">
              {mysteryResult.codeName}
            </h3>
            <p className="text-xs sm:text-sm text-slate-600 mt-1">{mysteryResult.description}</p>
          </div>

          {/* 1. HIỂN THỊ ĐÁP ÁN GIẢI MÃ KHOA HỌC TRẢ VỀ */}
          <div className="p-5 rounded-2xl bg-indigo-50/80 border-2 border-indigo-200 text-left space-y-2 shadow-xs">
            <div className="flex items-center gap-2 text-indigo-900 font-bold text-xs uppercase font-mono">
              <FileText className="w-4 h-4 text-indigo-600" />
              <span>ĐÁP ÁN GIẢI MÃ KHOA HỌC CỦA TRẠM:</span>
            </div>
            <p className="text-sm font-semibold text-indigo-950 leading-relaxed">
              {mysteryResult.solutionAnswer}
            </p>
          </div>

          {/* 2. HIỂN THỊ SỐ ĐIỂM RANDOM MAY MẮN (+5, +10, -5, -10, *2, :2) */}
          <div
            className={`p-6 sm:p-8 rounded-3xl border-4 text-center transition-all ${
              mysteryResult.effect === '*2'
                ? 'bg-gradient-to-r from-amber-100 via-yellow-100 to-amber-200 border-amber-400 shadow-xl shadow-amber-200 text-amber-950'
                : mysteryResult.pointsDelta > 0
                ? 'bg-emerald-50 border-emerald-400 text-emerald-950 shadow-lg shadow-emerald-100'
                : 'bg-rose-50 border-rose-300 text-rose-950 shadow-md shadow-rose-100'
            }`}
          >
            <div className="text-xs font-mono font-bold uppercase tracking-widest mb-1 opacity-70">
              SỐ ĐIỂM THƯỞNG RANDOM MAY MẮN:
            </div>

            <div className="text-5xl sm:text-6xl font-black font-mono tracking-tight my-2">
              {mysteryResult.effect === '*2' && '🌟 NHÂN ĐÔI (*2)'}
              {mysteryResult.effect === '+10' && '💎 +10 ĐIỂM'}
              {mysteryResult.effect === '+5' && '✨ +5 ĐIỂM'}
              {mysteryResult.effect === '-5' && '⚠️ -5 ĐIỂM'}
              {mysteryResult.effect === '-10' && '⚡ -10 ĐIỂM'}
              {mysteryResult.effect === ':2' && '🌀 CHIA ĐÔI (:2)'}
            </div>

            <p className="text-xs font-semibold mt-2 opacity-90">
              {mysteryResult.effect === '*2' && 'Vận may rực rỡ! Toàn bộ điểm số 3 vòng trước được nhân đôi!'}
              {mysteryResult.effect === '+10' && 'Hộp quà tuyệt hảo cộng thêm 10 điểm vào quỹ điểm!'}
              {mysteryResult.effect === '+5' && 'Thêm 5 điểm quý giá giúp củng cố vị trí trên bảng xếp hạng!'}
              {mysteryResult.effect === '-5' && 'Một chút sương mù hải tặc làm hao hụt 5 điểm số.'}
              {mysteryResult.effect === '-10' && 'Cơn bão biển sâu cuốn đi 10 điểm trong rương.'}
              {mysteryResult.effect === ':2' && 'Hố đen hư không đã chia đôi điểm số của 3 vòng trước!'}
            </p>
          </div>

          {/* 3. BẢNG SO SÁNH ĐIỂM TỔNG HỢP */}
          <div className="grid grid-cols-3 gap-3 p-4 rounded-2xl bg-slate-50 border border-slate-200 text-center font-mono">
            <div>
              <span className="text-[11px] text-slate-500 block">3 Vòng Trước</span>
              <strong className="text-base sm:text-lg text-slate-800 font-black">
                {mysteryResult.baseScore} pts
              </strong>
            </div>
            <div>
              <span className="text-[11px] text-slate-500 block">Biến Động Rương</span>
              <strong
                className={`text-base sm:text-lg font-black ${
                  mysteryResult.pointsDelta >= 0 ? 'text-emerald-600' : 'text-rose-600'
                }`}
              >
                {mysteryResult.pointsDelta >= 0
                  ? `+${mysteryResult.pointsDelta}`
                  : mysteryResult.pointsDelta}{' '}
                pts
              </strong>
            </div>
            <div>
              <span className="text-[11px] text-slate-500 block">Tổng Điểm Cuối</span>
              <strong className="text-base sm:text-lg text-amber-600 font-black">
                {mysteryResult.newTotalScore} pts
              </strong>
            </div>
          </div>

          {/* Finish Button */}
          <button
            type="button"
            onClick={onFinishGame}
            className="w-full py-4 rounded-2xl bg-gradient-to-r from-amber-500 via-yellow-500 to-amber-600 hover:from-amber-400 hover:to-yellow-400 text-slate-950 font-black text-sm uppercase tracking-wider shadow-xl shadow-amber-500/25 flex items-center justify-center gap-2 cursor-pointer transition-all transform hover:scale-101"
          >
            <span>TIẾN ĐẾN XEM KẾT QUẢ & GIẤY CHỨNG NHẬN PÉTRUS KÝ</span>
            <ArrowRight className="w-5 h-5 stroke-[2.5]" />
          </button>
        </div>
      )}
    </div>
  );
};
