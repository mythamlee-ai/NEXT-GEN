import React, { useState } from 'react';
import {
  Compass,
  Map as MapIcon,
  Lock,
  CheckCircle2,
  Sparkles,
  ArrowRight,
  ShieldCheck,
  Star,
  Key,
  Gem,
  Award,
  HelpCircle,
  Zap,
  Image as ImageIcon,
  QrCode,
  Flame,
  Flag,
  Trophy,
} from 'lucide-react';
import { Team, RoundNumber } from '../../types';
import { ChibiMascot } from '../../components/ChibiMascot';
import { audioManager } from '../../services/audioManager';

interface TreasureMapProps {
  team: Team;
  onEnterRound: (round: RoundNumber) => void;
  onOpenInventory: () => void;
  onViewFinalChest?: () => void;
}

interface IslandData {
  round: RoundNumber;
  code: string;
  name: string;
  vietnameseTitle: string;
  subtitle: string;
  emoji: string;
  themeColor: string;
  rewardName: string;
  rewardType: string;
  keyword: string;
  storyIntro: string;
}

const ISLANDS: IslandData[] = [
  {
    round: 1,
    code: 'ISLAND-1',
    name: 'THE SCIENCE ISLAND',
    vietnameseTitle: 'ĐẢO KHOA HỌC',
    subtitle: 'Thử thách 9 câu hỏi liên môn Lý – Hóa – Sinh',
    emoji: '🏝️',
    themeColor: 'sky',
    rewardName: 'Chìa Khóa Quang Phổ Alpha',
    rewardType: 'Chìa Khóa',
    keyword: 'LƯỢNG TỬ',
    storyIntro:
      'Hòn đảo khoa học cổ kính được bảo vệ bởi 9 phong ấn tự nhiên. Hãy dùng trí tuệ liên môn Vật lý, Hóa học và Sinh học để thu thập Chìa Khóa Alpha đầu tiên!',
  },
  {
    round: 2,
    code: 'ISLAND-2',
    name: 'THE MYSTERY TEACHER',
    vietnameseTitle: 'VÙNG ĐẤT BÍ ẨN',
    subtitle: 'Nhận diện các Nhà Giáo KHTN Pétrus Ký huyền thoại',
    emoji: '🏰',
    themeColor: 'indigo',
    rewardName: 'Mảnh Bản Đồ Cổ Pétrus Ký',
    rewardType: 'Mảnh Bản Đồ',
    keyword: 'NGUYÊN TỐ',
    storyIntro:
      'Một lâu đài ẩn hiện trong sương mù, nơi lưu giữ chân dung và manh mối của các bậc thầy khoa học trường Pétrus Ký. Hãy khám phá và lật mở tấm Bản Đồ Dẫn Đường!',
  },
  {
    round: 3,
    code: 'ISLAND-3',
    name: 'THE PICTURE CAVE',
    vietnameseTitle: 'HANG ĐỘNG HÌNH ẢNH',
    subtitle: 'Đuổi hình bắt chữ thám mã khoa học rebus',
    emoji: '🪨',
    themeColor: 'purple',
    rewardName: 'Đá Quý Thạch Anh Thám Mã',
    rewardType: 'Đá Quý',
    keyword: 'TIẾN HÓA',
    storyIntro:
      'Hang động thạch nhũ khắc đầy những bức tranh câu đố thị giác cổ xưa. Giải mã bí mật hình ảnh để lấy về Viên Thạch Anh soi đường!',
  },
  {
    round: 4,
    code: 'ISLAND-4',
    name: 'THE FINAL TREASURE',
    vietnameseTitle: 'KHO BÁU CUỐI CÙNG',
    subtitle: 'Quét mã QR trạm thực địa & Bẻ khóa Rương Báu',
    emoji: '💎',
    themeColor: 'amber',
    rewardName: 'La Bàn Vàng Tối Thượng Next Gen',
    rewardType: 'La Bàn Vàng',
    keyword: 'VÔ ĐỊCH NEXT GEN',
    storyIntro:
      'Địa điểm phong ấn Rương Kho Báu Pétrus Ký. Hãy kích hoạt máy quét thực địa để hợp nhất toàn bộ 4 mật mã và mở bung rương kho báu!',
  },
];

export const TreasureMap: React.FC<TreasureMapProps> = ({
  team,
  onEnterRound,
  onOpenInventory,
  onViewFinalChest,
}) => {
  const [selectedIsland, setSelectedIsland] = useState<IslandData>(
    ISLANDS.find((i) => i.round === team.currentRound) || ISLANDS[0]
  );

  const getIslandStatus = (round: RoundNumber) => {
    if (team.status === 'finished') return 'COMPLETED';
    if (team.currentRound > round) return 'COMPLETED';
    if (team.currentRound === round) return 'CURRENT';
    return 'LOCKED';
  };

  const handleIslandClick = (island: IslandData) => {
    audioManager.playButtonTap();
    setSelectedIsland(island);
  };

  const currentStatus = getIslandStatus(selectedIsland.round);
  const isAllCompleted = team.status === 'finished' || team.currentRound > 4;

  return (
    <div className="max-w-6xl mx-auto px-4 py-6 sm:py-10">
      {/* Top Header Card */}
      <div className="bg-white border-2 border-amber-300 rounded-3xl p-6 sm:p-8 shadow-xl mb-8 relative overflow-hidden">
        <div className="absolute top-0 right-0 w-80 h-80 bg-amber-100/60 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute bottom-0 left-0 w-80 h-80 bg-sky-100/50 rounded-full blur-3xl pointer-events-none" />

        <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 relative z-10">
          <div className="flex items-center gap-4">
            <ChibiMascot
              expression="pointing"
              size="lg"
              showSpeechBubble={true}
              speechText={`Chào Đội ${team.teamName}! Hãy chọn vùng đất đang sáng để tiếp tục hành trình săn tìm kho báu nhé!`}
              accessory="map"
            />
            <div>
              <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-100 border border-amber-300 text-amber-900 text-xs font-mono font-bold tracking-wider mb-2">
                <Compass className="w-4 h-4 text-amber-600 animate-spin" style={{ animationDuration: '10s' }} />
                <span>HẢI TRÌNH KHO BÁU PEK SCIENCE QUEST</span>
              </div>
              <h1 className="text-2xl sm:text-3xl font-black text-slate-900 tracking-tight">
                PEK TREASURE MAP
              </h1>
              <p className="text-xs sm:text-sm text-slate-600 font-semibold mt-1">
                Đội: <strong className="text-slate-900">{team.teamName}</strong> • Lớp: <strong className="text-sky-700">{team.className}</strong> • Đội Trưởng: <strong className="text-indigo-700">{team.captainName}</strong>
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2.5">
            <button
              onClick={() => {
                audioManager.playPop();
                onOpenInventory();
              }}
              className="px-5 py-3 rounded-2xl bg-gradient-to-r from-amber-50 to-yellow-50 hover:from-amber-100 hover:to-yellow-100 border-2 border-amber-300 text-amber-950 font-bold text-xs sm:text-sm flex items-center gap-2 shadow-sm transition-all cursor-pointer transform hover:scale-102"
            >
              <span>🎒 KHO ĐỒ THÁM HIỂM</span>
              <span className="w-6 h-6 rounded-full bg-amber-400 text-slate-950 flex items-center justify-center font-mono font-black text-xs shadow-inner">
                {Math.min(4, Math.max(0, team.currentRound - 1))}
              </span>
            </button>
          </div>
        </div>
      </div>

      {/* Main Interactive Archipelago Map */}
      <div className="bg-gradient-to-b from-amber-50/80 via-sky-50/40 to-white border-2 border-amber-300 rounded-3xl p-6 sm:p-10 shadow-xl mb-8 relative overflow-hidden">
        {/* Subtle Water Waves Background Graphics */}
        <div className="absolute inset-0 opacity-15 pointer-events-none bg-[radial-gradient(#0284c7_1px,transparent_1px)] [background-size:24px_24px]" />

        {/* Trail from START -> 🏝️ VÒNG 1 -> 🏰 VÒNG 2 -> 🪨 VÒNG 3 -> 💎 VÒNG 4 -> 🏴‍☠️ FINAL TREASURE */}
        <div className="relative mb-12">
          {/* Desktop Curved Dotted Path */}
          <div className="hidden lg:block relative">
            <svg
              className="w-full h-24 overflow-visible"
              viewBox="0 0 1000 80"
              fill="none"
              xmlns="http://www.w3.org/2000/svg"
            >
              {/* Inactive Base Dotted Line */}
              <path
                d="M 60 40 Q 200 10 260 40 T 480 40 T 700 40 T 920 40"
                stroke="#cbd5e1"
                strokeWidth="4"
                strokeDasharray="8 8"
              />

              {/* Active Golden Animated Line */}
              <path
                d={`M 60 40 ${
                  team.currentRound >= 2 ? 'Q 200 10 260 40' : ''
                } ${team.currentRound >= 3 ? 'T 480 40' : ''} ${
                  team.currentRound >= 4 ? 'T 700 40' : ''
                } ${team.status === 'finished' ? 'T 920 40' : ''}`}
                stroke="#f59e0b"
                strokeWidth="5"
                strokeDasharray="8 8"
                className="animate-pulse"
              />
            </svg>
          </div>

          {/* 6 Map Stations: START -> Island 1 -> Island 2 -> Island 3 -> Island 4 -> Final Chest */}
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3 sm:gap-4 relative z-10">
            {/* 1. START Point */}
            <div className="p-4 rounded-3xl border-2 border-emerald-300 bg-white/90 shadow-sm flex flex-col items-center justify-center text-center">
              <span className="text-[10px] font-mono font-bold px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800 uppercase tracking-wider mb-2">
                KHỞI HÀNH
              </span>
              <div className="w-14 h-14 rounded-2xl bg-emerald-100 border-2 border-emerald-300 flex items-center justify-center text-2xl shadow-sm mb-2">
                🚩
              </div>
              <h4 className="font-black text-xs text-slate-800">START</h4>
              <p className="text-[10px] text-slate-500 font-medium">Cảng Thám Hiểm</p>
              <div className="mt-2 text-emerald-600">
                <CheckCircle2 className="w-4 h-4" />
              </div>
            </div>

            {/* 2-5: The 4 Islands */}
            {ISLANDS.map((island) => {
              const status = getIslandStatus(island.round);
              const isSelected = selectedIsland.round === island.round;

              return (
                <div
                  key={island.code}
                  onClick={() => handleIslandClick(island)}
                  className={`relative p-4 rounded-3xl border-2 transition-all cursor-pointer transform hover:scale-102 duration-200 select-none flex flex-col items-center justify-between text-center ${
                    status === 'CURRENT'
                      ? 'bg-white border-amber-400 shadow-xl shadow-amber-400/25 ring-4 ring-amber-200 animate-pulse-gentle'
                      : status === 'COMPLETED'
                      ? 'bg-gradient-to-b from-emerald-50 to-white border-emerald-300 shadow-md'
                      : 'bg-white/80 border-slate-200 opacity-70'
                  } ${isSelected ? 'ring-2 ring-sky-500 scale-102' : ''}`}
                >
                  {/* Status Beacon */}
                  <span
                    className={`text-[9px] font-mono font-bold px-2 py-0.5 rounded-full uppercase tracking-wider mb-2 ${
                      status === 'COMPLETED'
                        ? 'bg-emerald-100 text-emerald-800'
                        : status === 'CURRENT'
                        ? 'bg-amber-100 text-amber-900 font-black animate-pulse'
                        : 'bg-slate-100 text-slate-500'
                    }`}
                  >
                    {status === 'COMPLETED'
                      ? 'ĐÃ VƯỢT QUA'
                      : status === 'CURRENT'
                      ? 'ĐANG MỞ'
                      : 'LOCKED'}
                  </span>

                  {/* Island Big Emoji */}
                  <div
                    className={`w-14 h-14 rounded-2xl flex items-center justify-center text-2xl shadow-sm transition-transform mb-2 ${
                      status === 'CURRENT'
                        ? 'bg-amber-100 border-2 border-amber-400 scale-110 shadow-md shadow-amber-200'
                        : status === 'COMPLETED'
                        ? 'bg-emerald-100 border-2 border-emerald-300'
                        : 'bg-slate-100 border-2 border-slate-200 grayscale opacity-60'
                    }`}
                  >
                    {island.emoji}
                  </div>

                  <span className="text-[10px] font-mono font-bold text-slate-400 uppercase tracking-wider">
                    VÒNG {island.round}
                  </span>
                  <h4 className="font-black text-xs text-slate-900 mt-0.5 leading-snug line-clamp-1">
                    {island.vietnameseTitle}
                  </h4>
                  <p className="text-[10px] text-slate-500 line-clamp-1 mt-0.5 font-medium">
                    {island.rewardType}
                  </p>

                  {/* Bottom Icon Indicator */}
                  <div className="mt-2">
                    {status === 'COMPLETED' ? (
                      <div className="flex items-center gap-1 text-emerald-600 font-bold text-[10px]">
                        <CheckCircle2 className="w-4 h-4" />
                        <Star className="w-3.5 h-3.5 fill-amber-400 text-amber-500" />
                      </div>
                    ) : status === 'CURRENT' ? (
                      <Sparkles className="w-4 h-4 text-amber-500 animate-spin" style={{ animationDuration: '4s' }} />
                    ) : (
                      <Lock className="w-4 h-4 text-slate-400" />
                    )}
                  </div>

                  {/* Standing Chibi Companion next to the active island */}
                  {status === 'CURRENT' && (
                    <div className="absolute -top-5 -right-3 z-20 pointer-events-none animate-bounce-gentle">
                      <ChibiMascot expression="excited" size="sm" />
                    </div>
                  )}
                </div>
              );
            })}

            {/* 6. FINAL TREASURE Destination Node */}
            <div
              onClick={() => {
                if (isAllCompleted && onViewFinalChest) {
                  audioManager.playChestOpen();
                  onViewFinalChest();
                }
              }}
              className={`p-4 rounded-3xl border-2 transition-all flex flex-col items-center justify-between text-center select-none ${
                isAllCompleted
                  ? 'bg-gradient-to-b from-amber-100 via-yellow-50 to-white border-amber-400 shadow-xl shadow-amber-400/30 cursor-pointer animate-pulse ring-4 ring-amber-200'
                  : 'bg-white/80 border-slate-200 opacity-60'
              }`}
            >
              <span
                className={`text-[9px] font-mono font-bold px-2 py-0.5 rounded-full uppercase tracking-wider mb-2 ${
                  isAllCompleted
                    ? 'bg-amber-500 text-slate-950 font-black'
                    : 'bg-slate-100 text-slate-400'
                }`}
              >
                {isAllCompleted ? 'ĐÃ MỞ BUNG!' : 'PHONG ẤN'}
              </span>

              <div
                className={`w-14 h-14 rounded-2xl flex items-center justify-center text-2xl shadow-sm mb-2 ${
                  isAllCompleted
                    ? 'bg-gradient-to-tr from-amber-400 to-yellow-300 border-2 border-amber-500 shadow-md'
                    : 'bg-slate-100 border-2 border-slate-200 grayscale opacity-60'
                }`}
              >
                🏴‍☠️
              </div>

              <span className="text-[10px] font-mono font-bold text-amber-700 uppercase tracking-wider">
                ĐÍCH ĐẾN
              </span>
              <h4 className="font-black text-xs text-slate-900 mt-0.5 leading-snug">
                FINAL CHEST
              </h4>
              <p className="text-[10px] text-slate-500 font-medium line-clamp-1">Rương Kho Báu</p>

              <div className="mt-2">
                {isAllCompleted ? (
                  <Trophy className="w-4 h-4 text-amber-600 animate-bounce" />
                ) : (
                  <Lock className="w-4 h-4 text-slate-400" />
                )}
              </div>
            </div>
          </div>
        </div>

        {/* Selected Island Dossier & Narrative Briefing */}
        <div className="bg-white border-2 border-slate-200 rounded-3xl p-6 sm:p-8 shadow-md relative">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
            <div className="space-y-2.5 flex-1">
              <div className="flex items-center gap-3">
                <span className="text-3xl">{selectedIsland.emoji}</span>
                <div>
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-mono font-bold text-amber-800 bg-amber-100 px-2 py-0.5 rounded uppercase tracking-wider border border-amber-300">
                      VÙNG ĐẤT #{selectedIsland.round}
                    </span>
                    <span className="text-xs font-mono text-slate-500">{selectedIsland.code}</span>
                  </div>
                  <h3 className="text-xl sm:text-2xl font-black text-slate-900 mt-0.5">
                    {selectedIsland.vietnameseTitle} ({selectedIsland.name})
                  </h3>
                </div>
              </div>

              {/* Narrative Story Line */}
              <p className="text-xs sm:text-sm text-slate-700 leading-relaxed font-medium">
                {selectedIsland.storyIntro}
              </p>

              {/* Reward & Status Details (Không hiển thị mật khẩu/mật từ) */}
              <div className="flex flex-wrap items-center gap-3 pt-2 text-xs font-mono">
                <span className="bg-slate-100 text-slate-800 px-3 py-1 rounded-xl border border-slate-200 font-bold">
                  🎁 Phần thưởng: <strong>{selectedIsland.rewardName}</strong>
                </span>
                <span
                  className={`px-3 py-1 rounded-xl border font-bold ${
                    currentStatus === 'COMPLETED'
                      ? 'bg-emerald-50 text-emerald-800 border-emerald-300'
                      : currentStatus === 'CURRENT'
                      ? 'bg-amber-50 text-amber-900 border-amber-300'
                      : 'bg-slate-100 text-slate-500 border-slate-200'
                  }`}
                >
                  🔐 Trạng thái phong ấn: <strong>{
                    currentStatus === 'COMPLETED'
                      ? 'ĐÃ GIẢI MÃ'
                      : currentStatus === 'CURRENT'
                      ? 'ĐANG THỬ THÁCH'
                      : 'ĐANG BỊ KHÓA'
                  }</strong>
                </span>
              </div>
            </div>

            {/* Action Button: Enter Land or Locked Indicator */}
            <div className="flex-shrink-0">
              {currentStatus === 'CURRENT' ? (
                <button
                  onClick={() => {
                    audioManager.playUnlock();
                    onEnterRound(selectedIsland.round);
                  }}
                  className="w-full md:w-auto px-8 py-4 rounded-2xl bg-gradient-to-r from-amber-500 via-yellow-500 to-amber-600 hover:from-amber-400 hover:to-yellow-400 text-slate-950 font-black text-sm sm:text-base flex items-center justify-center gap-2 shadow-xl shadow-amber-500/25 transition-all transform hover:scale-102 active:scale-98 cursor-pointer animate-pulse"
                >
                  <span>TIẾN VÀO {selectedIsland.vietnameseTitle}</span>
                  <ArrowRight className="w-5 h-5 stroke-[2.5]" />
                </button>
              ) : currentStatus === 'COMPLETED' ? (
                <button
                  onClick={() => {
                    audioManager.playPop();
                    onEnterRound(selectedIsland.round);
                  }}
                  className="w-full md:w-auto px-6 py-3.5 rounded-2xl bg-emerald-50 hover:bg-emerald-100 border-2 border-emerald-300 text-emerald-800 font-bold text-xs sm:text-sm flex items-center justify-center gap-2 transition-all cursor-pointer"
                >
                  <CheckCircle2 className="w-4 h-4" />
                  <span>XEM LẠI VÙNG ĐÃ GIẢI MÃ</span>
                </button>
              ) : (
                <div className="px-6 py-3.5 rounded-2xl bg-slate-100 border border-slate-200 text-slate-400 font-bold text-xs sm:text-sm flex items-center justify-center gap-2 cursor-not-allowed">
                  <Lock className="w-4 h-4" />
                  <span>VÙNG ĐẤT ĐANG BỊ PHONG ẤN</span>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
