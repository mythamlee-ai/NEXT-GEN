import React, { useState, useEffect } from 'react';
import {
  Shield,
  Sparkles,
  UserCheck,
  ArrowRight,
  KeyRound,
  AlertCircle,
  Compass,
  Trophy,
  Users,
} from 'lucide-react';
import { Team } from '../../types';
import { ScoringEngine } from '../../services/scoringEngine';
import { storageService } from '../../services/storageService';
import { audioManager } from '../../services/audioManager';
import { ChibiMascot } from '../../components/ChibiMascot';

interface CheckInProps {
  onCheckInSuccess: (team: Team) => void;
}

export const CheckIn: React.FC<CheckInProps> = ({ onCheckInSuccess }) => {
  const [mode, setMode] = useState<'create' | 'resume'>('create');
  const [existingTeams, setExistingTeams] = useState<Team[]>(() => storageService.getTeams());

  // Form states
  const [teamName, setTeamName] = useState('');
  const [className, setClassName] = useState('');
  const [captainName, setCaptainName] = useState('');
  const [resumeCode, setResumeCode] = useState('');
  const [errorMsg, setErrorMsg] = useState('');

  useEffect(() => {
    setExistingTeams(storageService.getTeams());
    const unsub = storageService.subscribe((event) => {
      if (event.type === 'TEAMS_UPDATED' || event.type === 'FACTORY_RESET') {
        setExistingTeams(storageService.getTeams());
      }
    });
    return () => unsub();
  }, []);

  const handleSelectExistingTeam = (t: Team) => {
    storageService.setCurrentTeamId(t.id);
    audioManager.playUnlock();
    onCheckInSuccess(t);
  };

  const handleCreateTeam = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');

    if (!teamName.trim()) {
      setErrorMsg('Vui lòng nhập tên đội thi của bạn.');
      return;
    }
    if (!className.trim()) {
      setErrorMsg('Vui lòng nhập lớp (ví dụ: 12 Lý, 11A1, 10 Tin).');
      return;
    }
    if (!captainName.trim()) {
      setErrorMsg('Vui lòng nhập họ và tên của Đội Trưởng.');
      return;
    }

    const uniqueCode = ScoringEngine.generateTeamCode();
    const newTeam: Team = {
      id: 'team_' + Date.now() + '_' + Math.random().toString(36).substring(2, 7),
      teamCode: uniqueCode,
      teamName: teamName.trim(),
      className: className.trim(),
      captainName: captainName.trim(),
      members: [captainName.trim()],
      createdAt: Date.now(),
      currentRound: 1,
      status: 'ready',
      score: 0,
      roundScores: { 1: 0, 2: 0, 3: 0, 4: 0 },
      elapsedTime: 0,
      roundTimes: { 1: 0, 2: 0, 3: 0, 4: 0 },
      answersHistory: [],
      currentQuestionIndex: 0,
      questionSeed: uniqueCode + '_' + Date.now(),
      unlockedNextGenCodes: [],
      bonusQRCodes: [],
    };

    storageService.saveTeam(newTeam);
    storageService.setCurrentTeamId(newTeam.id);
    audioManager.playChestOpen();
    onCheckInSuccess(newTeam);
  };

  const handleResumeTeam = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');

    const cleanCode = resumeCode.trim().toUpperCase();
    if (!cleanCode) {
      setErrorMsg('Vui lòng nhập Mã đội (ví dụ: PEK-7F29).');
      return;
    }

    const teams = storageService.getTeams();
    const found = teams.find(
      (t) => t.teamCode.toUpperCase() === cleanCode || t.id === cleanCode
    );

    if (found) {
      storageService.setCurrentTeamId(found.id);
      audioManager.playUnlock();
      onCheckInSuccess(found);
    } else {
      setErrorMsg(`Không tìm thấy đội với mã "${cleanCode}". Vui lòng kiểm tra lại.`);
    }
  };

  const handleQuickDemo = () => {
    const demoCode = ScoringEngine.generateTeamCode();
    const demoTeam: Team = {
      id: 'team_demo_' + Date.now(),
      teamCode: demoCode,
      teamName: 'Lượng Tử Sáng Tạo',
      className: '12 Lý - THPT PeK',
      captainName: 'Nguyễn Minh Triết (Đội Trưởng)',
      members: ['Nguyễn Minh Triết'],
      createdAt: Date.now(),
      currentRound: 1,
      status: 'ready',
      score: 0,
      roundScores: { 1: 0, 2: 0, 3: 0, 4: 0 },
      elapsedTime: 0,
      roundTimes: { 1: 0, 2: 0, 3: 0, 4: 0 },
      answersHistory: [],
      currentQuestionIndex: 0,
      questionSeed: 'DEMO_SEED_' + Date.now(),
      unlockedNextGenCodes: [],
      bonusQRCodes: [],
    };
    storageService.saveTeam(demoTeam);
    storageService.setCurrentTeamId(demoTeam.id);
    audioManager.playChestOpen();
    onCheckInSuccess(demoTeam);
  };

  return (
    <div className="max-w-xl mx-auto px-4 py-6 sm:py-10">
      {/* Hero Header with Cute Chibi Mascot */}
      <div className="text-center mb-6 flex flex-col items-center">
        <ChibiMascot
          expression="greeting"
          size="lg"
          showSpeechBubble={true}
          speechText="Chào mừng bạn đến với Đấu trường Next Gen! Hãy check-in nhé!"
        />

        <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-sky-100 border border-sky-300 text-sky-800 text-xs font-mono font-bold tracking-wider mt-3 mb-2 shadow-sm">
          <Sparkles className="w-3.5 h-3.5 text-sky-600" />
          <span>PORTAL NHIỆM VỤ THẾ HỆ MỚI • NEXT GEN</span>
        </div>

        <h1 className="text-3xl sm:text-4xl font-black tracking-tight text-slate-900 mb-1">
          PEK SCIENCE QUEST
        </h1>
        <p className="text-base sm:text-lg font-bold bg-gradient-to-r from-sky-600 via-indigo-600 to-cyan-600 bg-clip-text text-transparent">
          THE FINAL CODE • NEXT GEN
        </p>
        <p className="text-xs sm:text-sm text-slate-500 italic mt-0.5">
          “Một hành trình – Bốn mật mã – Một nhà vô địch.”
        </p>
      </div>

      {/* Mode Switcher */}
      <div className="grid grid-cols-2 p-1.5 bg-white border border-slate-200 rounded-2xl mb-6 shadow-sm">
        <button
          type="button"
          onClick={() => {
            setMode('create');
            setErrorMsg('');
            audioManager.playPop();
          }}
          className={`py-2.5 rounded-xl text-xs sm:text-sm font-bold transition-all flex items-center justify-center gap-2 cursor-pointer ${
            mode === 'create'
              ? 'bg-gradient-to-r from-sky-500 to-blue-600 text-white shadow-md shadow-sky-500/25'
              : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          <Compass className="w-4 h-4" />
          <span>Đăng Ký Đội Mới</span>
        </button>

        <button
          type="button"
          onClick={() => {
            setMode('resume');
            setErrorMsg('');
            audioManager.playPop();
          }}
          className={`py-2.5 rounded-xl text-xs sm:text-sm font-bold transition-all flex items-center justify-center gap-2 cursor-pointer ${
            mode === 'resume'
              ? 'bg-gradient-to-r from-indigo-500 to-purple-600 text-white shadow-md shadow-indigo-500/25'
              : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          <KeyRound className="w-4 h-4" />
          <span>Tiếp Tục Lượt Chơi</span>
        </button>
      </div>

      {/* Card Form - Bright & Modern */}
      <div className="bg-white border border-slate-200/80 rounded-3xl p-6 sm:p-8 shadow-xl shadow-slate-200/50 relative overflow-hidden">
        {/* Soft pastel decorative glow */}
        <div className="absolute top-0 right-0 w-48 h-48 bg-sky-200/40 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute bottom-0 left-0 w-48 h-48 bg-indigo-200/30 rounded-full blur-3xl pointer-events-none" />

        {errorMsg && (
          <div className="mb-5 p-3.5 rounded-2xl bg-red-50 border border-red-200 text-red-700 text-xs sm:text-sm flex items-start gap-2.5 shadow-sm">
            <AlertCircle className="w-4 h-4 flex-shrink-0 mt-0.5 text-red-500" />
            <span>{errorMsg}</span>
          </div>
        )}

        {mode === 'create' ? (
          <form onSubmit={handleCreateTeam} className="space-y-4">
            <div>
              <label className="block text-xs uppercase font-bold tracking-wider text-slate-700 mb-1.5">
                Tên Đội Chơi <span className="text-rose-500">*</span>
              </label>
              <input
                type="text"
                value={teamName}
                onChange={(e) => setTeamName(e.target.value)}
                placeholder="VD: Lượng Tử Tốc Độ, Biệt Đội Menđen..."
                className="w-full bg-slate-50 border border-slate-300 focus:border-sky-500 focus:bg-white focus:ring-2 focus:ring-sky-200 rounded-xl px-4 py-3 text-slate-800 placeholder-slate-400 outline-none text-sm transition-all"
                autoFocus
              />
            </div>

            <div>
              <label className="block text-xs uppercase font-bold tracking-wider text-slate-700 mb-1.5">
                Lớp / Khối <span className="text-rose-500">*</span>
              </label>
              <input
                type="text"
                value={className}
                onChange={(e) => setClassName(e.target.value)}
                placeholder="VD: 12 Lý, 11A1, 10 Hóa..."
                className="w-full bg-slate-50 border border-slate-300 focus:border-sky-500 focus:bg-white focus:ring-2 focus:ring-sky-200 rounded-xl px-4 py-3 text-slate-800 placeholder-slate-400 outline-none text-sm transition-all"
              />
            </div>

            {/* Replaced Members with Captain Name */}
            <div>
              <label className="block text-xs uppercase font-bold tracking-wider text-slate-700 mb-1.5 flex items-center justify-between">
                <span>Tên Đội Trưởng <span className="text-rose-500">*</span></span>
                <span className="text-[11px] text-sky-600 font-mono normal-case">Đại diện nhận thưởng</span>
              </label>
              <div className="relative">
                <input
                  type="text"
                  value={captainName}
                  onChange={(e) => setCaptainName(e.target.value)}
                  placeholder="Nhập họ và tên Đội Trưởng..."
                  className="w-full bg-slate-50 border border-slate-300 focus:border-sky-500 focus:bg-white focus:ring-2 focus:ring-sky-200 rounded-xl pl-4 pr-10 py-3 text-slate-800 placeholder-slate-400 outline-none text-sm transition-all font-semibold"
                />
                <UserCheck className="w-5 h-5 text-sky-500 absolute right-3 top-3 pointer-events-none" />
              </div>
            </div>

            <div className="pt-3">
              <button
                type="submit"
                className="w-full py-4 rounded-2xl bg-gradient-to-r from-sky-500 via-blue-600 to-indigo-600 hover:from-sky-400 hover:to-indigo-500 text-white font-black text-sm sm:text-base flex items-center justify-center gap-2 shadow-lg shadow-sky-500/25 transition-all transform hover:scale-101 active:scale-98 cursor-pointer"
              >
                <span>XÁC NHẬN CHECK-IN & NHẬN MÃ NHIỆM VỤ</span>
                <ArrowRight className="w-5 h-5 stroke-[2.5]" />
              </button>

              {/* Quick Demo Button for teachers and evaluators */}
              <div className="mt-3 text-center">
                <button
                  type="button"
                  onClick={handleQuickDemo}
                  className="w-full py-2.5 rounded-xl bg-sky-50 hover:bg-sky-100 border border-sky-300 text-sky-800 font-bold text-xs flex items-center justify-center gap-1.5 transition-all cursor-pointer shadow-sm"
                >
                  <Sparkles className="w-3.5 h-3.5 text-sky-600" />
                  <span>Chơi Thử Bằng Đội Mẫu (Quick Demo 1-Click)</span>
                </button>
              </div>

              <p className="text-center text-[11px] text-slate-500 mt-2.5 font-mono">
                Hệ thống cấp Mã Đội Độc Bản (VD: PEK-7F29) để lưu phiên
              </p>
            </div>
          </form>
        ) : (
          <form onSubmit={handleResumeTeam} className="space-y-5">
            <div>
              <label className="block text-xs uppercase font-bold tracking-wider text-slate-700 mb-2">
                Mã Đội Của Bạn
              </label>
              <div className="relative">
                <input
                  type="text"
                  value={resumeCode}
                  onChange={(e) => setResumeCode(e.target.value.toUpperCase())}
                  placeholder="VD: PEK-7F29"
                  className="w-full bg-slate-50 border border-slate-300 focus:border-indigo-500 focus:bg-white focus:ring-2 focus:ring-indigo-200 rounded-xl px-4 py-3.5 text-center text-slate-900 placeholder-slate-400 font-mono text-xl uppercase tracking-widest outline-none transition-all font-bold"
                  autoFocus
                />
                <KeyRound className="w-5 h-5 text-indigo-500 absolute right-4 top-4 pointer-events-none" />
              </div>
              <p className="text-xs text-slate-500 mt-2">
                Nhập mã đội đã cấp để khôi phục tiến trình khi bạn đổi máy hoặc tải lại trang.
              </p>
            </div>

            <button
              type="submit"
              className="w-full py-4 rounded-2xl bg-gradient-to-r from-indigo-500 to-purple-600 hover:from-indigo-400 hover:to-purple-500 text-white font-bold text-sm sm:text-base flex items-center justify-center gap-2 shadow-lg shadow-indigo-500/25 transition-all transform hover:scale-101 active:scale-98 cursor-pointer"
            >
              <span>KHÔI PHỤC PHIÊN CHƠI</span>
              <ArrowRight className="w-5 h-5 stroke-[2.5]" />
            </button>

            {/* Quick Multi-Device Team Selector */}
            {existingTeams.length > 0 && (
              <div className="pt-5 border-t border-slate-200">
                <div className="flex items-center justify-between mb-3">
                  <span className="text-xs font-mono font-bold text-slate-700 uppercase flex items-center gap-1.5">
                    <Users className="w-3.5 h-3.5 text-indigo-600" />
                    <span>ĐỘI THI TRÊN HỆ THỐNG ({existingTeams.length})</span>
                  </span>
                  <span className="text-[11px] font-mono text-emerald-600 font-bold flex items-center gap-1">
                    <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
                    Đồng bộ đa máy
                  </span>
                </div>

                <div className="space-y-2 max-h-56 overflow-y-auto pr-1">
                  {existingTeams.map((t) => (
                    <div
                      key={t.id}
                      onClick={() => handleSelectExistingTeam(t)}
                      className="p-3 rounded-2xl bg-slate-50 hover:bg-indigo-50/70 border border-slate-200 hover:border-indigo-300 transition-all flex items-center justify-between cursor-pointer group shadow-xs"
                    >
                      <div className="min-w-0 pr-2">
                        <div className="flex items-center gap-2">
                          <h4 className="font-bold text-xs sm:text-sm text-slate-900 group-hover:text-indigo-700 truncate">
                            {t.teamName}
                          </h4>
                          <span className="text-[10px] font-mono font-bold px-2 py-0.5 rounded-full bg-indigo-100 text-indigo-800">
                            {t.teamCode}
                          </span>
                        </div>
                        <p className="text-[11px] text-slate-500 mt-0.5">
                          {t.className} • Vòng {t.currentRound} ({t.score} điểm)
                        </p>
                      </div>

                      <button
                        type="button"
                        className="px-3 py-1.5 rounded-xl bg-white group-hover:bg-indigo-600 group-hover:text-white border border-slate-200 group-hover:border-indigo-600 text-[11px] font-bold text-slate-700 transition-all shadow-xs flex-shrink-0"
                      >
                        Vào chơi →
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </form>
        )}
      </div>

      {/* Info notice */}
      <div className="mt-6 text-center text-xs text-slate-500 font-mono">
        <p>Tổ Khoa học Tự nhiên – Trường Pétrus Ký • Science Quest</p>
      </div>
    </div>
  );
};
