import React, { useEffect, useState } from 'react';
import confetti from 'canvas-confetti';
import {
  Trophy,
  Award,
  Clock,
  CheckCircle,
  Zap,
  HelpCircle,
  Image as ImageIcon,
  QrCode,
  RotateCcw,
  Sparkles,
  BarChart2,
  FileCheck,
  UserCheck,
  Map as MapIcon,
  Check,
} from 'lucide-react';
import { Team } from '../../types';
import { ScoringEngine } from '../../services/scoringEngine';
import { audioManager } from '../../services/audioManager';
import { storageService } from '../../services/storageService';
import { CertificateModal } from './CertificateModal';
import { ChibiMascot } from '../../components/ChibiMascot';
import { TreasureChest } from '../../components/TreasureChest';

interface ResultsViewProps {
  team: Team;
  onViewLeaderboard: () => void;
  onPlayAgain: () => void;
  onViewMap?: () => void;
}

export const ResultsView: React.FC<ResultsViewProps> = ({
  team,
  onViewLeaderboard,
  onPlayAgain,
  onViewMap,
}) => {
  const [showCertificate, setShowCertificate] = useState<boolean>(false);

  useEffect(() => {
    // Play celebratory fanfare
    audioManager.playVictory();

    // Fire fireworks confetti
    try {
      const duration = 3 * 1000;
      const end = Date.now() + duration;

      const frame = () => {
        confetti({
          particleCount: 6,
          angle: 60,
          spread: 60,
          origin: { x: 0 },
          colors: ['#0284c7', '#8b5cf6', '#f59e0b', '#10b981'],
        });
        confetti({
          particleCount: 6,
          angle: 120,
          spread: 60,
          origin: { x: 1 },
          colors: ['#0284c7', '#8b5cf6', '#f59e0b', '#10b981'],
        });

        if (Date.now() < end) {
          requestAnimationFrame(frame);
        }
      };
      frame();
    } catch {
      // Ignored
    }
  }, []);

  // Compute live rank among all teams
  const allTeams = storageService.getTeams();
  const sortedTeams = [...allTeams].sort(ScoringEngine.compareTeams);
  const currentRank = sortedTeams.findIndex((t) => t.id === team.id) + 1;

  const totalCorrect = team.answersHistory.filter((ans) => ans.isCorrect).length;
  const totalQuestions = team.answersHistory.length;

  return (
    <div className="max-w-5xl mx-auto px-4 py-8 sm:py-12">
      {/* Victory Header Card with Animated Treasure Chest Component */}
      <div className="relative bg-white border-2 border-amber-300 rounded-3xl p-6 sm:p-10 shadow-2xl text-center overflow-hidden mb-8">
        <div className="absolute top-0 right-0 w-80 h-80 bg-amber-100/60 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute bottom-0 left-0 w-80 h-80 bg-sky-100/50 rounded-full blur-3xl pointer-events-none" />

        {/* Central Treasure Chest Sequence Component */}
        <div className="relative z-10 mb-6">
          <TreasureChest
            keysCollected={['Alpha (Lượng Tử)', 'Beta (Nguyên Tố)', 'Gamma (Tiến Hóa)', 'NextGen (Chung Cuộc)']}
            onRewardClaim={() => setShowCertificate(true)}
            autoPlay={true}
          />
        </div>

        {/* Team Honors */}
        <div className="relative z-10 max-w-xl mx-auto mb-6">
          <h1 className="text-3xl sm:text-4xl font-black text-slate-900 mb-2 tracking-tight">
            XUẤT SẮC MỞ BUNG RƯƠNG KHO BÁU!
          </h1>
          <p className="text-base sm:text-xl font-bold bg-gradient-to-r from-sky-600 via-indigo-600 to-amber-600 bg-clip-text text-transparent">
            Đội: {team.teamName} • Lớp: {team.className}
          </p>
          {team.captainName && (
            <p className="text-xs sm:text-sm text-slate-600 font-semibold mt-1 flex items-center justify-center gap-1.5">
              <UserCheck className="w-4 h-4 text-indigo-600" />
              <span>Đội Trưởng: <strong className="text-indigo-900">{team.captainName}</strong></span>
            </p>
          )}
        </div>

        {/* 4 Grand Score KPIs */}
        <div className="relative z-10 grid grid-cols-2 md:grid-cols-4 gap-3 sm:gap-4 mb-8">
          <div className="p-4 sm:p-5 rounded-2xl bg-amber-50/70 border border-amber-200 shadow-sm text-center">
            <span className="text-xs font-mono font-bold text-amber-700 uppercase tracking-wider block mb-1">
              HẠNG HIỆN TẠI
            </span>
            <div className="flex items-center justify-center gap-1.5">
              <Trophy className="w-6 h-6 text-amber-500" />
              <span className="text-3xl sm:text-4xl font-black text-slate-900 font-mono">
                #{currentRank}
              </span>
            </div>
          </div>

          <div className="p-4 sm:p-5 rounded-2xl bg-sky-50/70 border border-sky-200 shadow-sm text-center">
            <span className="text-xs font-mono font-bold text-sky-700 uppercase tracking-wider block mb-1">
              TỔNG ĐIỂM SỐ
            </span>
            <div className="flex items-center justify-center gap-1.5">
              <Award className="w-6 h-6 text-sky-600" />
              <span className="text-3xl sm:text-4xl font-black text-sky-700 font-mono">
                {team.score}
              </span>
            </div>
          </div>

          <div className="p-4 sm:p-5 rounded-2xl bg-indigo-50/70 border border-indigo-200 shadow-sm text-center">
            <span className="text-xs font-mono font-bold text-indigo-700 uppercase tracking-wider block mb-1">
              THỜI GIAN GIẢI
            </span>
            <div className="flex items-center justify-center gap-1.5">
              <Clock className="w-6 h-6 text-indigo-500" />
              <span className="text-2xl sm:text-3xl font-black text-indigo-800 font-mono">
                {ScoringEngine.formatTime(team.elapsedTime)}
              </span>
            </div>
          </div>

          <div className="p-4 sm:p-5 rounded-2xl bg-emerald-50/70 border border-emerald-200 shadow-sm text-center">
            <span className="text-xs font-mono font-bold text-emerald-700 uppercase tracking-wider block mb-1">
              ĐỘ CHÍNH XÁC
            </span>
            <div className="flex items-center justify-center gap-1.5">
              <CheckCircle className="w-6 h-6 text-emerald-500" />
              <span className="text-2xl sm:text-3xl font-black text-emerald-800 font-mono">
                {totalQuestions > 0 ? Math.round((totalCorrect / totalQuestions) * 100) : 100}%
              </span>
            </div>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="relative z-10 my-4 flex flex-wrap items-center justify-center gap-3">
          <button
            onClick={() => setShowCertificate(true)}
            className="px-6 py-3.5 rounded-2xl bg-gradient-to-r from-amber-500 to-yellow-500 hover:from-amber-400 hover:to-yellow-400 text-slate-950 font-black text-sm flex items-center gap-2 shadow-lg shadow-amber-500/25 transition-all cursor-pointer transform hover:scale-102"
          >
            <FileCheck className="w-5 h-5" />
            <span>XEM & XUẤT GIẤY CHỨNG NHẬN PÉTRUS KÝ</span>
          </button>

          {onViewMap && (
            <button
              onClick={onViewMap}
              className="px-6 py-3.5 rounded-2xl bg-amber-50 hover:bg-amber-100 text-amber-900 font-bold text-sm flex items-center gap-2 border border-amber-300 transition-all cursor-pointer"
            >
              <MapIcon className="w-5 h-5 text-amber-600" />
              <span>XEM LẠI BẢN ĐỒ KHO BÁU</span>
            </button>
          )}

          <button
            onClick={onViewLeaderboard}
            className="px-6 py-3.5 rounded-2xl bg-gradient-to-r from-sky-500 to-indigo-600 hover:from-sky-400 hover:to-indigo-500 text-white font-bold text-sm flex items-center gap-2 shadow-lg shadow-sky-500/25 transition-all cursor-pointer transform hover:scale-102"
          >
            <BarChart2 className="w-5 h-5" />
            <span>XEM BẢNG XẾP HẠNG TOÀN GIẢI</span>
          </button>

          <button
            onClick={onPlayAgain}
            className="px-6 py-3.5 rounded-2xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-sm flex items-center gap-2 transition-all cursor-pointer border border-slate-200"
          >
            <RotateCcw className="w-4 h-4" />
            <span>CHƠI LẠI TỪ ĐẦU</span>
          </button>
        </div>
      </div>

      {/* Round Breakdown Cards */}
      <h3 className="text-lg font-bold text-slate-900 mb-4 flex items-center gap-2">
        <Sparkles className="w-5 h-5 text-amber-500" />
        <span>CHI TIẾT 4 VÙNG ĐẤT ĐÃ KHÁM PHÁ:</span>
      </h3>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
        {/* Round 1 */}
        <div className="p-5 rounded-2xl bg-white border border-slate-200 shadow-sm">
          <div className="flex items-center justify-between mb-2">
            <span className="w-9 h-9 rounded-xl bg-sky-100 text-sky-600 flex items-center justify-center font-bold text-lg">
              🏝️
            </span>
            <span className="font-mono font-black text-sky-700 text-lg">
              {team.roundScores[1] || 0} pts
            </span>
          </div>
          <h4 className="font-bold text-slate-900 text-sm">Vòng 1: Đảo Khoa Học</h4>
          <p className="text-xs text-slate-500 mt-1">
            Thời gian: {ScoringEngine.formatTime(team.roundTimes[1] || 0)}
          </p>
        </div>

        {/* Round 2 */}
        <div className="p-5 rounded-2xl bg-white border border-slate-200 shadow-sm">
          <div className="flex items-center justify-between mb-2">
            <span className="w-9 h-9 rounded-xl bg-indigo-100 text-indigo-600 flex items-center justify-center font-bold text-lg">
              🏰
            </span>
            <span className="font-mono font-black text-indigo-700 text-lg">
              {team.roundScores[2] || 0} pts
            </span>
          </div>
          <h4 className="font-bold text-slate-900 text-sm">Vòng 2: Vùng Đất Bí Ẩn</h4>
          <p className="text-xs text-slate-500 mt-1">
            Thời gian: {ScoringEngine.formatTime(team.roundTimes[2] || 0)}
          </p>
        </div>

        {/* Round 3 */}
        <div className="p-5 rounded-2xl bg-white border border-slate-200 shadow-sm">
          <div className="flex items-center justify-between mb-2">
            <span className="w-9 h-9 rounded-xl bg-purple-100 text-purple-600 flex items-center justify-center font-bold text-lg">
              🪨
            </span>
            <span className="font-mono font-black text-purple-700 text-lg">
              {team.roundScores[3] || 0} pts
            </span>
          </div>
          <h4 className="font-bold text-slate-900 text-sm">Vòng 3: Hang Động Hình Ảnh</h4>
          <p className="text-xs text-slate-500 mt-1">
            Thời gian: {ScoringEngine.formatTime(team.roundTimes[3] || 0)}
          </p>
        </div>

        {/* Round 4 */}
        <div className="p-5 rounded-2xl bg-white border border-slate-200 shadow-sm">
          <div className="flex items-center justify-between mb-2">
            <span className="w-9 h-9 rounded-xl bg-amber-100 text-amber-600 flex items-center justify-center font-bold text-lg">
              💎
            </span>
            <span className="font-mono font-black text-amber-700 text-lg">
              {team.roundScores[4] || 0} pts
            </span>
          </div>
          <h4 className="font-bold text-slate-900 text-sm">Vòng 4: Kho Báu Cuối Cùng</h4>
          <p className="text-xs text-slate-500 mt-1">
            Thời gian: {ScoringEngine.formatTime(team.roundTimes[4] || 0)}
          </p>
        </div>
      </div>

      {/* Certificate Modal */}
      {showCertificate && (
        <CertificateModal
          team={team}
          rank={currentRank}
          onClose={() => setShowCertificate(false)}
        />
      )}
    </div>
  );
};
