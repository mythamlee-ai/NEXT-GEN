import React, { useState, useEffect } from 'react';
import confetti from 'canvas-confetti';
import {
  Sparkles,
  CheckCircle2,
  XCircle,
  Clock,
  ArrowRight,
  AlertCircle,
  HelpCircle,
  Award,
} from 'lucide-react';
import { Team, Question } from '../../types';
import { GameEngine } from '../../services/gameEngine';
import { ScoringEngine } from '../../services/scoringEngine';
import { Timer } from '../../components/Timer';
import { audioManager } from '../../services/audioManager';
import { ChibiMascot } from '../../components/ChibiMascot';

interface Round1ViewProps {
  team: Team;
  onRoundComplete: () => void;
}

export const Round1View: React.FC<Round1ViewProps> = ({ team, onRoundComplete }) => {
  const [questions, setQuestions] = useState<Question[]>([]);
  const [warningMsg, setWarningMsg] = useState<string | undefined>();
  const [currentIndex, setCurrentIndex] = useState<number>(0);
  const [selectedOption, setSelectedOption] = useState<'A' | 'B' | 'C' | 'D' | null>(null);
  const [isAnswerSubmitted, setIsAnswerSubmitted] = useState<boolean>(false);
  const [isTimeout, setIsTimeout] = useState<boolean>(false);
  const [timeTaken, setTimeTaken] = useState<number>(0);
  const [earnedPoints, setEarnedPoints] = useState<number>(0);

  useEffect(() => {
    const { questions: qList, warning } = GameEngine.getTeamRound1Questions(team);
    setQuestions(qList);
    setWarningMsg(warning);

    // Sync current question index from team session if available
    const savedIndex = Math.min(team.currentQuestionIndex || 0, qList.length);
    setCurrentIndex(savedIndex);
  }, [team.id]);

  const currentQ = questions[currentIndex];

  /**
   * REQUIREMENT 7:
   * Khi chọn đáp án:
   * - khóa lựa chọn
   * - hiển thị đúng/sai
   * - hiển thị explanation ngắn
   * - cập nhật score
   * - phát hiệu ứng.
   * Không hiển thị correctAnswer trước khi người chơi trả lời.
   */
  const handleSelectOption = (key: 'A' | 'B' | 'C' | 'D') => {
    if (isAnswerSubmitted || !currentQ) return;

    setSelectedOption(key);
    setIsAnswerSubmitted(true);
    setIsTimeout(false);

    const isCorrect = key === currentQ.correctAnswer;
    const finalTimeTaken = Math.max(1, timeTaken);
    const pointsAwarded = isCorrect
      ? ScoringEngine.calculateQuestionScore(currentQ.points, true, finalTimeTaken, currentQ.timeLimit)
      : 0;

    setEarnedPoints(pointsAwarded);

    // Play feedback effects
    if (isCorrect) {
      audioManager.playVictory();
      try {
        confetti({
          particleCount: 50,
          spread: 60,
          origin: { y: 0.65 },
        });
      } catch {
        // Fallback
      }
    } else {
      audioManager.playWarning();
    }

    // Persist answer in GameEngine
    GameEngine.recordAnswer(
      team,
      1,
      currentQ.id,
      key,
      isCorrect,
      pointsAwarded,
      finalTimeTaken
    );
  };

  /**
   * Handle question timeout
   */
  const handleTimeout = () => {
    if (isAnswerSubmitted || !currentQ) return;

    setIsAnswerSubmitted(true);
    setIsTimeout(true);
    setSelectedOption(null);
    setEarnedPoints(0);
    audioManager.playWarning();

    GameEngine.recordAnswer(
      team,
      1,
      currentQ.id,
      'TIMEOUT',
      false,
      0,
      currentQ.timeLimit
    );
  };

  const handleNextQuestion = () => {
    setSelectedOption(null);
    setIsAnswerSubmitted(false);
    setIsTimeout(false);
    setTimeTaken(0);
    setEarnedPoints(0);

    const nextIdx = currentIndex + 1;
    if (nextIdx >= questions.length) {
      // Completed all 9 questions of Round 1
      onRoundComplete();
    } else {
      setCurrentIndex(nextIdx);
    }
  };

  // Completed all questions state
  if (!currentQ) {
    return (
      <div className="max-w-2xl mx-auto px-4 py-16 text-center">
        <div className="w-16 h-16 rounded-full bg-emerald-100 text-emerald-600 mx-auto flex items-center justify-center mb-4">
          <CheckCircle2 className="w-8 h-8" />
        </div>
        <h2 className="text-2xl font-black text-slate-900 mb-2">Đã Hoàn Thành Vòng 1!</h2>
        <p className="text-slate-600 mb-6">Tất cả 9 câu hỏi liên môn khoa học đã được giải mã.</p>
        <button
          onClick={onRoundComplete}
          className="px-8 py-3.5 rounded-xl bg-sky-600 text-white font-bold hover:bg-sky-500 transition-all cursor-pointer shadow-lg shadow-sky-600/30"
        >
          TIẾN VÀO BẢN ĐỒ TIẾP THEO
        </button>
      </div>
    );
  }

  const isCorrectAnswer = isAnswerSubmitted && selectedOption === currentQ.correctAnswer;

  return (
    <div className="max-w-3xl mx-auto px-4 py-6 sm:py-8">
      {/* Warning message if bank is small */}
      {warningMsg && (
        <div className="mb-4 p-3 rounded-xl bg-amber-50 border border-amber-300 text-amber-800 text-xs flex items-center gap-2">
          <AlertCircle className="w-4 h-4 flex-shrink-0 text-amber-600" />
          <span>{warningMsg}</span>
        </div>
      )}

      {/* Header Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-5">
        <div className="flex items-center gap-3">
          <ChibiMascot
            expression={
              isAnswerSubmitted
                ? isCorrectAnswer
                  ? 'celebrating'
                  : 'surprised'
                : 'thinking'
            }
            size="sm"
            showSpeechBubble={false}
          />
          <div>
            <div className="flex items-center gap-2 mb-0.5">
              <span className="text-[11px] font-mono font-bold text-sky-700 uppercase tracking-widest">
                VÒNG 1: SCIENCE CODE BREAKER
              </span>
            </div>
            {/* REQUIREMENT 7: Display CÂU X / 9 */}
            <h2 className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight">
              CÂU {currentIndex + 1} / 9
            </h2>
          </div>
        </div>

        {/* Real Countdown Timer */}
        <div className="flex items-center gap-3">
          <Timer
            key={`${currentQ.id}_${currentIndex}`}
            timeLimit={currentQ.timeLimit}
            onTimeout={handleTimeout}
            isPaused={isAnswerSubmitted}
            onTick={(_timeLeft, taken) => setTimeTaken(taken)}
          />
        </div>
      </div>

      {/* Progress Bar (9 questions) */}
      <div className="flex items-center gap-1.5 mb-6">
        {questions.map((q, idx) => {
          const isDone = idx < currentIndex;
          const isCurrent = idx === currentIndex;
          return (
            <div
              key={q.id}
              className={`h-2 flex-1 rounded-full transition-all duration-300 ${
                isCurrent
                  ? 'bg-sky-500 ring-2 ring-sky-300 scale-y-125'
                  : isDone
                  ? 'bg-emerald-500'
                  : 'bg-slate-200'
              }`}
            />
          );
        })}
      </div>

      {/* Question Card */}
      <div className="bg-white border border-slate-200 rounded-3xl p-6 sm:p-8 shadow-xl shadow-slate-100 mb-6 relative overflow-hidden">
        {/* Top Badges: Generic category to keep subjects mystery until answered */}
        <div className="flex flex-wrap items-center justify-between gap-3 mb-5">
          <div className="flex items-center gap-2">
            <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold bg-sky-50 text-sky-800 border border-sky-200">
              <Sparkles className="w-3.5 h-3.5 text-sky-600" />
              <span>MẬT MÃ KHOA HỌC TỰ NHIÊN</span>
            </span>
            <span className="px-2.5 py-1 rounded-full text-xs font-bold bg-slate-100 text-slate-700">
              +{currentQ.points} điểm
            </span>
          </div>

          <span className="text-xs text-slate-500 font-mono">
            Thời gian: {currentQ.timeLimit}s
          </span>
        </div>

        {/* Question Prompt */}
        <h3 className="text-lg sm:text-xl font-bold text-slate-900 leading-snug mb-6">
          {currentQ.question}
        </h3>

        {/* 4 Choices Grid (A, B, C, D) */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 mb-6">
          {(['A', 'B', 'C', 'D'] as const).map((key) => {
            const isSelected = selectedOption === key;
            const isCorrectOption = currentQ.correctAnswer === key;

            // Compute styling according to state
            let cardClasses = 'bg-slate-50 hover:bg-slate-100/90 border-slate-200 text-slate-800';
            let keyBadgeClasses = 'bg-white text-slate-600 border border-slate-200';

            if (!isAnswerSubmitted) {
              cardClasses = 'bg-slate-50 hover:bg-sky-50 hover:border-sky-300 border-slate-200 text-slate-800 cursor-pointer active:scale-[0.99]';
            } else {
              // Answer already submitted
              if (isSelected && isCorrectOption) {
                // Chosen correctly
                cardClasses = 'bg-emerald-50 border-2 border-emerald-500 text-emerald-950 font-bold shadow-md shadow-emerald-100';
                keyBadgeClasses = 'bg-emerald-600 text-white';
              } else if (isSelected && !isCorrectOption) {
                // Chosen wrongly
                cardClasses = 'bg-rose-50 border-2 border-rose-500 text-rose-950 font-bold shadow-md shadow-rose-100';
                keyBadgeClasses = 'bg-rose-600 text-white';
              } else if (!isSelected && isCorrectOption) {
                // Reveal correct option after wrong answer or timeout
                cardClasses = 'bg-emerald-50/70 border-2 border-emerald-400 text-emerald-900 font-semibold';
                keyBadgeClasses = 'bg-emerald-500 text-white';
              } else {
                cardClasses = 'bg-slate-50/60 border-slate-200 text-slate-400 opacity-60';
              }
            }

            return (
              <button
                key={key}
                type="button"
                onClick={() => handleSelectOption(key)}
                disabled={isAnswerSubmitted}
                className={`p-4 rounded-2xl border text-left transition-all duration-150 flex items-start gap-3.5 ${cardClasses} disabled:cursor-default`}
              >
                <span
                  className={`w-7 h-7 rounded-xl flex items-center justify-center font-mono font-bold text-xs flex-shrink-0 transition-colors ${keyBadgeClasses}`}
                >
                  {key}
                </span>

                <div className="flex-1 pt-0.5">
                  <span className="text-sm leading-relaxed block">
                    {currentQ.options[key]}
                  </span>

                  {/* Inline visual tags after answering */}
                  {isAnswerSubmitted && isSelected && isCorrectOption && (
                    <span className="inline-flex items-center gap-1 mt-1 text-xs text-emerald-700 font-bold">
                      <CheckCircle2 className="w-3.5 h-3.5" />
                      Chính xác! (+{earnedPoints} điểm)
                    </span>
                  )}
                  {isAnswerSubmitted && isSelected && !isCorrectOption && (
                    <span className="inline-flex items-center gap-1 mt-1 text-xs text-rose-600 font-bold">
                      <XCircle className="w-3.5 h-3.5" />
                      Chưa chính xác
                    </span>
                  )}
                  {isAnswerSubmitted && !isSelected && isCorrectOption && (
                    <span className="inline-flex items-center gap-1 mt-1 text-xs text-emerald-700 font-bold">
                      <CheckCircle2 className="w-3.5 h-3.5" />
                      Đáp án đúng của câu này
                    </span>
                  )}
                </div>
              </button>
            );
          })}
        </div>

        {/* Timeout banner */}
        {isTimeout && (
          <div className="mb-4 p-3 rounded-2xl bg-rose-50 border border-rose-300 text-rose-800 text-xs flex items-center gap-2">
            <Clock className="w-4 h-4 text-rose-600 flex-shrink-0" />
            <span className="font-bold">Đã hết thời gian làm bài! Đáp án đúng được hiển thị bên trên.</span>
          </div>
        )}

        {/* Short Explanation Card (Displayed immediately upon answering) */}
        {isAnswerSubmitted && (
          <div className="bg-sky-50/80 border border-sky-200 rounded-2xl p-4 mb-6 transition-all duration-300 animate-in fade-in slide-in-from-bottom-2">
            <div className="flex items-center gap-2 mb-1.5">
              <span className="text-[11px] font-mono font-bold text-sky-800 uppercase bg-sky-200/80 px-2 py-0.5 rounded">
                GIẢI THÍCH KHOA HỌC
              </span>
              <span className="text-xs text-slate-500">
                [{currentQ.subject} - {currentQ.topic}]
              </span>
            </div>
            <p className="text-xs sm:text-sm text-sky-950 leading-relaxed font-medium">
              {currentQ.explanation}
            </p>
          </div>
        )}

        {/* Bottom Bar: Action & Next */}
        <div className="flex items-center justify-between pt-4 border-t border-slate-100">
          <p className="text-xs text-slate-500 font-medium">
            {!isAnswerSubmitted
              ? 'Nhấp chọn một đáp án bất kỳ để trả lời'
              : isCorrectAnswer
              ? `Tuyệt vời! Bạn nhận được +${earnedPoints} điểm`
              : 'Hãy đọc kỹ lời giải thích để ghi nhớ kiến thức'}
          </p>

          {isAnswerSubmitted && (
            <button
              onClick={handleNextQuestion}
              className="px-6 py-3 rounded-xl bg-sky-600 hover:bg-sky-500 text-white font-bold text-sm shadow-md shadow-sky-600/30 transition-all flex items-center gap-2 cursor-pointer animate-pulse"
            >
              <span>{currentIndex === questions.length - 1 ? 'HOÀN THÀNH VÒNG 1' : 'CÂU TIẾP THEO'}</span>
              <ArrowRight className="w-4 h-4 stroke-[2.5]" />
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
