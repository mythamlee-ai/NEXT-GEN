import { Team, TeamAnswerRecord } from '../types';

export class ScoringEngine {
  /**
   * Calculates points for a given question answer
   */
  public static calculateQuestionScore(
    basePoints: number,
    isCorrect: boolean,
    timeTaken: number,
    timeLimit: number
  ): number {
    if (!isCorrect) return 0;
    // Base score is guaranteed on correct
    let points = basePoints;
    // Fast answer bonus: if answered within first 25% of time limit, +2 bonus points
    if (timeTaken <= timeLimit * 0.25) {
      points += 2;
    }
    return points;
  }

  /**
   * Calculates points for Round 2 Clue solving:
   * Clue 1: 40 điểm
   * Clue 2: 30 điểm
   * Clue 3: 20 điểm
   * Clue 4: 10 điểm
   */
  public static getRound2CluePoints(clueNumber: number): number {
    switch (clueNumber) {
      case 1:
        return 40;
      case 2:
        return 30;
      case 3:
        return 20;
      case 4:
        return 10;
      default:
        return 10;
    }
  }

  /**
   * Calculates points for Round 2 Teacher clue guessing (legacy support)
   */
  public static calculateTeacherScore(
    maxPoints: number,
    cluesOpenedCount: number,
    penaltyPerClue: number = 8
  ): number {
    const penalty = Math.max(0, (cluesOpenedCount - 1) * penaltyPerClue);
    return Math.max(10, maxPoints - penalty);
  }

  /**
   * Compares two teams for Leaderboard ranking:
   * 1. Higher total score
   * 2. Lower elapsed time
   * 3. Higher number of correct answers
   * 4. Earliest completion time
   */
  public static compareTeams(a: Team, b: Team): number {
    // 1. Total score (descending)
    if (b.score !== a.score) {
      return b.score - a.score;
    }

    // 2. Elapsed time (ascending - faster is better)
    if (a.elapsedTime !== b.elapsedTime) {
      return a.elapsedTime - b.elapsedTime;
    }

    // 3. Total correct answers
    const aCorrect = a.answersHistory.filter((ans) => ans.isCorrect).length;
    const bCorrect = b.answersHistory.filter((ans) => ans.isCorrect).length;
    if (bCorrect !== aCorrect) {
      return bCorrect - aCorrect;
    }

    // 4. Earliest completedAt or createdAt
    const aTime = a.completedAt || a.createdAt;
    const bTime = b.completedAt || b.createdAt;
    return aTime - bTime;
  }

  /**
   * Formats seconds into MM:SS
   */
  public static formatTime(seconds: number): string {
    const m = Math.floor(seconds / 60);
    const s = Math.floor(seconds % 60);
    return `${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
  }

  /**
   * Generates a unique Team Code e.g. "PEK-7F29"
   */
  public static generateTeamCode(): string {
    const chars = '23456789ABCDEFGHJKLMNPQRSTUVWXYZ';
    let code = 'PEK-';
    for (let i = 0; i < 4; i++) {
      code += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    return code;
  }
}
